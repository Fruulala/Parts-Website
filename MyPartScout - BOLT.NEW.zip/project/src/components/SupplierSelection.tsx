import React, { useState, useEffect } from 'react';
import { Store, ChevronRight, ArrowLeft } from 'lucide-react';
import { supabase, Supplier } from '../lib/supabase';
import { PuppyLogo } from './PuppyLogo';

interface SupplierSelectionProps {
  vehicle: { year: number; make: string; model: string; engine: string };
  partInfo: { category: string; part: string };
  onNext: (selectedSuppliers: string[]) => void;
  onBack: () => void;
}

export const SupplierSelection: React.FC<SupplierSelectionProps> = ({
  vehicle,
  partInfo,
  onNext,
  onBack,
}) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedSuppliers, setSelectedSuppliers] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    const { data, error } = await supabase
      .from('suppliers')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (!error && data) {
      setSuppliers(data);
    }
    setLoading(false);
  };

  const toggleSupplier = (supplierName: string) => {
    setSelectedSuppliers((prev) =>
      prev.includes(supplierName)
        ? prev.filter((s) => s !== supplierName)
        : [...prev, supplierName]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowAnimation(true);
    setTimeout(() => {
      setShowAnimation(false);
      onNext(selectedSuppliers);
    }, 3000);
  };

  return (
    <div className="max-w-2xl mx-auto">
      {showAnimation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-2xl p-12 flex flex-col items-center">
            <PuppyLogo animated size="lg" />
            <p className="mt-6 text-2xl font-bold text-slate-900">Searching for prices...</p>
            <p className="mt-2 text-slate-600">Our puppy is digging for the best deals!</p>
          </div>
        </div>
      )}
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to part selection
        </button>

        <div className="bg-slate-50 rounded-xl p-4 mb-6 space-y-2">
          <div>
            <span className="text-sm font-medium text-slate-600">Vehicle: </span>
            <span className="text-slate-900 font-semibold">
              {vehicle.year} {vehicle.make} {vehicle.model} - {vehicle.engine}
            </span>
          </div>
          <div>
            <span className="text-sm font-medium text-slate-600">Part: </span>
            <span className="text-slate-900 font-semibold">
              {partInfo.category} - {partInfo.part}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <Store className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Select Suppliers</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-3">
            {loading ? (
              <div className="text-center py-8 text-slate-600">Loading suppliers...</div>
            ) : (
              suppliers.map((supplier) => (
                <label
                  key={supplier.id}
                  className="flex items-center gap-4 p-4 border-2 border-slate-200 rounded-lg cursor-pointer hover:border-slate-900 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={selectedSuppliers.includes(supplier.name)}
                    onChange={() => toggleSupplier(supplier.name)}
                    className="w-5 h-5 text-slate-900 border-slate-300 rounded focus:ring-slate-900"
                  />
                  <span className="flex-1 font-medium text-slate-900">{supplier.name}</span>
                </label>
              ))
            )}
          </div>

          {selectedSuppliers.length > 0 && (
            <div className="bg-blue-50 text-blue-900 px-4 py-3 rounded-lg text-sm">
              {selectedSuppliers.length} supplier{selectedSuppliers.length > 1 ? 's' : ''} selected
            </div>
          )}

          <button
            type="submit"
            disabled={selectedSuppliers.length === 0}
            className="w-full bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            Search Prices
            <ChevronRight className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
