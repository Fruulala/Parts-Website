/*
  # Add Phone Number and Logo Support

  1. Changes
    - Add phone_number column to supplier_locations table
    - Add logo_url column to suppliers table
    
  2. Details
    - phone_number: Store supplier location phone numbers from Google Places
    - logo_url: Store supplier brand logo URLs
*/

-- Add phone number to supplier locations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'supplier_locations' AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE supplier_locations ADD COLUMN phone_number text;
  END IF;
END $$;

-- Add logo URL to suppliers
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'suppliers' AND column_name = 'logo_url'
  ) THEN
    ALTER TABLE suppliers ADD COLUMN logo_url text;
  END IF;
END $$;