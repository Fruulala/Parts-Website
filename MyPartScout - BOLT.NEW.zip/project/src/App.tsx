import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './components/Auth/LoginPage';
import { AdminLogin } from './components/Auth/AdminLogin';
import { HomePage } from './components/HomePage';
import { VehicleSelection } from './components/VehicleSelection';
import { PartSelection } from './components/PartSelection';
import { SupplierSelection } from './components/SupplierSelection';
import { SearchResults } from './components/SearchResults';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { OrderConfirmation } from './components/OrderConfirmation';
import { OrderHistory } from './components/OrderHistory';
import { SupplierManagement } from './components/SupplierManagement';
import { LocationSetup } from './components/LocationSetup';
import { ManageLocations } from './components/ManageLocations';
import { AdminPanel } from './components/Admin/AdminPanel';
import { supabase } from './lib/supabase';

type Page =
  | 'home'
  | 'vehicle'
  | 'part'
  | 'supplier'
  | 'results'
  | 'cart'
  | 'checkout'
  | 'confirmation'
  | 'orders'
  | 'manage-suppliers'
  | 'manage-locations';

interface VehicleInfo {
  year: number;
  make: string;
  model: string;
  engine: string;
}

interface PartInfo {
  category: string;
  part: string;
}

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [isAdminRoute, setIsAdminRoute] = useState(false);

  useEffect(() => {
    const path = window.location.pathname;
    setIsAdminRoute(path === '/psadm1n2025' || path === '/psadm1n2025/');
  }, []);
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [vehicleInfo, setVehicleInfo] = useState<VehicleInfo | null>(null);
  const [partInfo, setPartInfo] = useState<PartInfo | null>(null);
  const [selectedSuppliers, setSelectedSuppliers] = useState<string[]>([]);
  const [orderNumber, setOrderNumber] = useState('');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900 mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return isAdminRoute ? <AdminLogin /> : <LoginPage />;
  }

  // Show admin panel for admin users (skip location setup for admins)
  if (profile?.role === 'admin') {
    const handleAdminLogout = async () => {
      try {
        localStorage.clear();
        sessionStorage.clear();
        await supabase.auth.signOut();
        window.location.href = '/';
        setTimeout(() => {
          window.location.reload();
        }, 100);
      } catch (error) {
        console.error('Logout error:', error);
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = '/';
        setTimeout(() => {
          window.location.reload();
        }, 100);
      }
    };

    return (
      <AdminPanel
        onLogout={handleAdminLogout}
      />
    );
  }

  if (profile && !profile.has_completed_location_setup) {
    return <LocationSetup onComplete={() => window.location.reload()} />;
  }

  const handleStartSearch = () => {
    setVehicleInfo(null);
    setPartInfo(null);
    setSelectedSuppliers([]);
    setCurrentPage('vehicle');
  };

  const handleVehicleNext = (vehicle: VehicleInfo) => {
    setVehicleInfo(vehicle);
    setCurrentPage('part');
  };

  const handlePartNext = (part: PartInfo) => {
    setPartInfo(part);
    setCurrentPage('supplier');
  };

  const handleSupplierNext = (suppliers: string[]) => {
    setSelectedSuppliers(suppliers);
    setCurrentPage('results');
  };

  const handleCheckoutComplete = (ordNum: string) => {
    setOrderNumber(ordNum);
    setCurrentPage('confirmation');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-8 px-4">
      {currentPage === 'home' && (
        <HomePage
          onStartSearch={handleStartSearch}
          onViewOrders={() => setCurrentPage('orders')}
          onViewCart={() => setCurrentPage('cart')}
          onManageLocations={() => setCurrentPage('manage-locations')}
        />
      )}

      {currentPage === 'vehicle' && (
        <VehicleSelection onNext={handleVehicleNext} onBack={() => setCurrentPage('home')} />
      )}

      {currentPage === 'part' && vehicleInfo && (
        <PartSelection
          vehicle={vehicleInfo}
          onNext={handlePartNext}
          onBack={() => setCurrentPage('vehicle')}
        />
      )}

      {currentPage === 'supplier' && vehicleInfo && partInfo && (
        <SupplierSelection
          vehicle={vehicleInfo}
          partInfo={partInfo}
          onNext={handleSupplierNext}
          onBack={() => setCurrentPage('part')}
        />
      )}

      {currentPage === 'results' && vehicleInfo && partInfo && (
        <SearchResults
          vehicle={vehicleInfo}
          partInfo={partInfo}
          suppliers={selectedSuppliers}
          onBack={() => setCurrentPage('supplier')}
          onViewCart={() => setCurrentPage('cart')}
        />
      )}

      {currentPage === 'cart' && (
        <Cart
          onBack={() => setCurrentPage(vehicleInfo ? 'results' : 'home')}
          onCheckout={() => setCurrentPage('checkout')}
        />
      )}

      {currentPage === 'checkout' && (
        <Checkout onBack={() => setCurrentPage('cart')} onComplete={handleCheckoutComplete} />
      )}

      {currentPage === 'confirmation' && (
        <OrderConfirmation
          orderNumber={orderNumber}
          onViewOrders={() => setCurrentPage('orders')}
          onNewSearch={handleStartSearch}
        />
      )}

      {currentPage === 'orders' && <OrderHistory onBack={() => setCurrentPage('home')} />}

      {currentPage === 'manage-suppliers' && (
        <SupplierManagement onBack={() => setCurrentPage('home')} />
      )}

      {currentPage === 'manage-locations' && (
        <ManageLocations onBack={() => setCurrentPage('home')} />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
