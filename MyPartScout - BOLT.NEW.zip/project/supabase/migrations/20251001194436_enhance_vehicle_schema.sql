/*
  # Enhanced Vehicle Database Schema

  1. Changes to Tables
    - Add `trim` column to vehicles table for sub-models/trims
    - Add `engine_code` column for detailed engine specifications
    - Add `engine_displacement` for precise engine size
    - Add `fuel_type` column
    - Add `drive_type` column (FWD, RWD, AWD, 4WD)
    - Add `vehicle_type` column (Car, Truck, SUV, Van)
    
  2. New Tables
    - `vehicle_data_imports`
      - Track bulk imports of vehicle data
      - Store import source and timestamp
    
  3. Updates
    - Remove unique constraint on vehicles to allow multiple trims per model
    - Add indexes for faster lookups
*/

-- Drop existing unique constraint if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'vehicles_year_make_model_engine_key'
  ) THEN
    ALTER TABLE vehicles DROP CONSTRAINT vehicles_year_make_model_engine_key;
  END IF;
END $$;

-- Add new columns to vehicles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'trim'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN trim text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'engine_code'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN engine_code text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'engine_displacement'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN engine_displacement text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'fuel_type'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN fuel_type text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'drive_type'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN drive_type text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vehicles' AND column_name = 'vehicle_type'
  ) THEN
    ALTER TABLE vehicles ADD COLUMN vehicle_type text DEFAULT '';
  END IF;
END $$;

-- Create vehicle_data_imports table
CREATE TABLE IF NOT EXISTS vehicle_data_imports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL,
  records_imported integer DEFAULT 0,
  status text DEFAULT 'pending',
  imported_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE vehicle_data_imports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view imports"
  ON vehicle_data_imports FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create imports"
  ON vehicle_data_imports FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vehicles_year ON vehicles(year);
CREATE INDEX IF NOT EXISTS idx_vehicles_make ON vehicles(make);
CREATE INDEX IF NOT EXISTS idx_vehicles_model ON vehicles(model);
CREATE INDEX IF NOT EXISTS idx_vehicles_lookup ON vehicles(year, make, model);
