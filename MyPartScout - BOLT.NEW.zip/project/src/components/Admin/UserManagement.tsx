import React, { useState, useEffect } from 'react';
import { Search, Plus, Trash2, Eye, Monitor, Smartphone, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

interface User {
  id: string;
  first_name: string;
  last_name: string;
  company_name: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  phone_number: string;
  role: string;
  created_at: string;
}

interface ActivityLog {
  id: string;
  action: string;
  details: any;
  ip_address: string;
  user_agent: string;
  device_type: string;
  created_at: string;
}

interface AuditLog {
  id: string;
  action: string;
  resource_type: string;
  resource_id: string;
  old_values: any;
  new_values: any;
  created_at: string;
  admin?: {
    first_name: string;
    last_name: string;
  };
}

export const UserManagement: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddUser, setShowAddUser] = useState(false);

  useEffect(() => {
    loadUsers();
    loadAuditLogs();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [searchTerm, users]);

  const loadUsers = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setUsers(data);
    }
    setLoading(false);
  };

  const loadAuditLogs = async () => {
    const { data } = await supabase
      .from('audit_logs')
      .select(`
        *,
        admin:profiles!audit_logs_admin_id_fkey(first_name, last_name)
      `)
      .order('created_at', { ascending: false })
      .limit(50);

    if (data) {
      setAuditLogs(data as any);
    }
  };

  const loadUserActivity = async (userId: string) => {
    const { data } = await supabase
      .from('activity_logs')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) {
      setActivityLogs(data);
    }
  };

  const filterUsers = () => {
    if (!searchTerm.trim()) {
      setFilteredUsers(users);
      return;
    }

    const term = searchTerm.toLowerCase();
    const filtered = users.filter(
      (user) =>
        user.phone_number?.toLowerCase().includes(term) ||
        user.company_name?.toLowerCase().includes(term) ||
        user.first_name?.toLowerCase().includes(term) ||
        user.last_name?.toLowerCase().includes(term)
    );
    setFilteredUsers(filtered);
  };

  const deleteUser = async (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;

    const confirmMessage = `Are you sure you want to delete ${user.first_name} ${user.last_name}?\n\nThis will:\n- Delete their profile\n- Remove their authentication account\n- Delete all their data\n\nThis action cannot be undone.`;

    if (!confirm(confirmMessage)) {
      return;
    }

    try {
      const { error: profileError } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);

      if (profileError) throw profileError;

      await loadUsers();
      setSelectedUser(null);
      alert('User account deleted successfully');
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Error deleting user: ' + (error as Error).message);
    }
  };

  const viewUserDetails = async (user: User) => {
    setSelectedUser(user);
    await loadUserActivity(user.id);
  };

  if (loading) {
    return <div className="text-center py-8">Loading users...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">User Management</h2>
          <p className="text-slate-600">Manage registered customers and their accounts</p>
        </div>
        <button
          onClick={() => setShowAddUser(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add User
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by phone number or company name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Name</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Company</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Phone</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Address</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Role</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-slate-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-4">
                    <p className="text-sm font-medium text-slate-900">
                      {user.first_name} {user.last_name}
                    </p>
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-sm text-slate-600">{user.company_name}</p>
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-sm text-slate-600">{user.phone_number}</p>
                  </td>
                  <td className="py-3 px-4">
                    <p className="text-sm text-slate-600">
                      {user.city}, {user.state} {user.zip_code}
                    </p>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                        user.role === 'admin'
                          ? 'bg-purple-100 text-purple-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {user.role}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => viewUserDetails(user)}
                        className="text-blue-600 hover:text-blue-700"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {user.id !== currentUser?.id && (
                        <button
                          onClick={() => deleteUser(user.id)}
                          className="text-red-600 hover:text-red-700"
                          title="Delete user"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-slate-600">No users found</div>
          )}
        </div>
      </div>

      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">
                    {selectedUser.first_name} {selectedUser.last_name}
                  </h3>
                  <p className="text-sm text-slate-600">{selectedUser.company_name}</p>
                </div>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <h4 className="text-lg font-bold text-slate-900 mb-3">Contact Information</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-600">Phone</p>
                    <p className="font-medium text-slate-900">{selectedUser.phone_number}</p>
                  </div>
                  <div>
                    <p className="text-slate-600">Address</p>
                    <p className="font-medium text-slate-900">
                      {selectedUser.address}, {selectedUser.city}, {selectedUser.state}{' '}
                      {selectedUser.zip_code}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-bold text-slate-900 mb-3">Activity History</h4>
                <div className="space-y-3">
                  {activityLogs.length > 0 ? (
                    activityLogs.map((log) => (
                      <div
                        key={log.id}
                        className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg"
                      >
                        <div className="mt-1">
                          {log.device_type === 'mobile' ? (
                            <Smartphone className="w-4 h-4 text-slate-600" />
                          ) : (
                            <Monitor className="w-4 h-4 text-slate-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900">{log.action}</p>
                          <p className="text-xs text-slate-600">
                            {log.ip_address} • {new Date(log.created_at).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-slate-600">No activity recorded</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-bold text-slate-900 mb-4">Audit Logs</h3>
        <div className="space-y-2">
          {auditLogs.length > 0 ? (
            auditLogs.map((log) => (
              <div key={log.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                <Clock className="w-4 h-4 text-slate-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">
                    {log.admin?.first_name} {log.admin?.last_name} {log.action} {log.resource_type}
                  </p>
                  <p className="text-xs text-slate-600">
                    {new Date(log.created_at).toLocaleString()}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-slate-600">No audit logs available</p>
          )}
        </div>
      </div>
    </div>
  );
};
