import React, { useState, useEffect } from 'react';
import { Settings, Save, Plus, Upload, X, Building2 } from 'lucide-react';
import { supabase, Supplier } from '../../lib/supabase';

export const SupplierManagement: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [editedSuppliers, setEditedSuppliers] = useState<Record<string, Partial<Supplier>>>({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSupplier, setNewSupplier] = useState({
    name: '',
    url: '',
    username: '',
    password: '',
    is_active: true,
  });
  const [uploadingLogo, setUploadingLogo] = useState<string | null>(null);

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    const { data, error } = await supabase
      .from('suppliers')
      .select('*')
      .order('name');

    if (!error && data) {
      setSuppliers(data);
    }
    setLoading(false);
  };

  const updateField = (supplierId: string, field: keyof Supplier, value: string | boolean) => {
    setEditedSuppliers((prev) => ({
      ...prev,
      [supplierId]: {
        ...prev[supplierId],
        [field]: value,
      },
    }));
  };

  const handleLogoUpload = async (supplierId: string, file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setUploadingLogo(supplierId);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `logos/${supplierId}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('supplier-logos')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('supplier-logos')
        .getPublicUrl(fileName);

      const { error: updateError } = await supabase
        .from('suppliers')
        .update({ logo_url: publicUrl })
        .eq('id', supplierId);

      if (updateError) throw updateError;

      setSuppliers((prev) =>
        prev.map((s) => (s.id === supplierId ? { ...s, logo_url: publicUrl } : s))
      );

      alert('Logo uploaded successfully!');
    } catch (error) {
      console.error('Error uploading logo:', error);
      alert('Failed to upload logo: ' + (error as Error).message);
    } finally {
      setUploadingLogo(null);
    }
  };

  const saveSupplier = async (supplier: Supplier) => {
    setSaving(supplier.id);

    const updates = editedSuppliers[supplier.id] || {};
    const { error } = await supabase
      .from('suppliers')
      .update(updates)
      .eq('id', supplier.id);

    if (!error) {
      setSuppliers((prev) =>
        prev.map((s) => (s.id === supplier.id ? { ...s, ...updates } : s))
      );
      setEditedSuppliers((prev) => {
        const newEdited = { ...prev };
        delete newEdited[supplier.id];
        return newEdited;
      });
      alert('Supplier updated successfully!');
    } else {
      alert('Error saving supplier: ' + error.message);
    }

    setSaving(null);
  };

  const addSupplier = async () => {
    if (!newSupplier.name.trim()) {
      alert('Please enter a supplier name');
      return;
    }

    setSaving('new');

    const { data, error } = await supabase
      .from('suppliers')
      .insert([newSupplier])
      .select()
      .single();

    if (!error && data) {
      setSuppliers((prev) => [...prev, data]);
      setNewSupplier({
        name: '',
        url: '',
        username: '',
        password: '',
        is_active: true,
      });
      setShowAddForm(false);
      alert('Supplier added successfully!');
    } else {
      alert('Error adding supplier: ' + error.message);
    }

    setSaving(null);
  };

  const hasChanges = (supplierId: string) => {
    return editedSuppliers[supplierId] && Object.keys(editedSuppliers[supplierId]).length > 0;
  };

  const getFieldValue = (supplier: Supplier, field: keyof Supplier) => {
    return editedSuppliers[supplier.id]?.[field] ?? supplier[field];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Manage Suppliers</h2>
          <p className="text-slate-600">
            Configure wholesale account credentials and logos for each supplier
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showAddForm ? 'Cancel' : 'Add Supplier'}
        </button>
      </div>

      {showAddForm && (
        <div className="bg-white rounded-lg shadow-sm p-6 border-2 border-blue-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Add New Supplier</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Supplier Name *
              </label>
              <input
                type="text"
                value={newSupplier.name}
                onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })}
                placeholder="e.g., NAPA Auto Parts"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Website URL
              </label>
              <input
                type="url"
                value={newSupplier.url}
                onChange={(e) => setNewSupplier({ ...newSupplier, url: e.target.value })}
                placeholder="https://www.example.com"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Username / Account ID
              </label>
              <input
                type="text"
                value={newSupplier.username}
                onChange={(e) => setNewSupplier({ ...newSupplier, username: e.target.value })}
                placeholder="Your wholesale account username"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Password / API Key
              </label>
              <input
                type="password"
                value={newSupplier.password}
                onChange={(e) => setNewSupplier({ ...newSupplier, password: e.target.value })}
                placeholder="Your wholesale account password"
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            <div className="md:col-span-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newSupplier.is_active}
                  onChange={(e) =>
                    setNewSupplier({ ...newSupplier, is_active: e.target.checked })
                  }
                  className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-600"
                />
                <span className="text-sm font-medium text-slate-700">Active</span>
              </label>
            </div>
          </div>

          <button
            onClick={addSupplier}
            disabled={saving === 'new'}
            className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            {saving === 'new' ? 'Adding...' : 'Add Supplier'}
          </button>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-blue-900">
            Configure your wholesale account credentials for each supplier to enable automatic price fetching. Upload logos to personalize the supplier display.
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-600">Loading suppliers...</div>
        ) : (
          <div className="space-y-6">
            {suppliers.map((supplier) => (
              <div key={supplier.id} className="border-2 border-slate-200 rounded-xl p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      {supplier.logo_url ? (
                        <img
                          src={supplier.logo_url}
                          alt={`${supplier.name} logo`}
                          className="w-16 h-16 object-contain rounded-lg border border-slate-200"
                        />
                      ) : (
                        <div className="w-16 h-16 bg-slate-100 rounded-lg border border-slate-200 flex items-center justify-center">
                          <Building2 className="w-8 h-8 text-slate-400" />
                        </div>
                      )}
                      <label className="absolute -bottom-1 -right-1 cursor-pointer bg-blue-600 text-white p-1.5 rounded-full hover:bg-blue-700 transition-colors">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleLogoUpload(supplier.id, file);
                          }}
                          className="hidden"
                          disabled={uploadingLogo === supplier.id}
                        />
                        {uploadingLogo === supplier.id ? (
                          <div className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full" />
                        ) : (
                          <Upload className="w-3 h-3" />
                        )}
                      </label>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900">{supplier.name}</h3>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={getFieldValue(supplier, 'is_active') as boolean}
                      onChange={(e) => updateField(supplier.id, 'is_active', e.target.checked)}
                      className="w-4 h-4 text-slate-900 border-slate-300 rounded focus:ring-slate-900"
                    />
                    <span className="text-sm font-medium text-slate-700">Active</span>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Website URL
                    </label>
                    <input
                      type="url"
                      value={getFieldValue(supplier, 'url') as string}
                      onChange={(e) => updateField(supplier.id, 'url', e.target.value)}
                      placeholder="https://www.example.com"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Username / Account ID
                    </label>
                    <input
                      type="text"
                      value={getFieldValue(supplier, 'username') as string}
                      onChange={(e) => updateField(supplier.id, 'username', e.target.value)}
                      placeholder="Your wholesale account username"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Password / API Key
                    </label>
                    <input
                      type="password"
                      value={getFieldValue(supplier, 'password') as string}
                      onChange={(e) => updateField(supplier.id, 'password', e.target.value)}
                      placeholder="Your wholesale account password"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>
                </div>

                {hasChanges(supplier.id) && (
                  <button
                    onClick={() => saveSupplier(supplier)}
                    disabled={saving === supplier.id}
                    className="mt-4 bg-slate-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    {saving === supplier.id ? 'Saving...' : 'Save Changes'}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-900">
            <strong>Note:</strong> Credentials are stored securely in the database. For production use, implement additional encryption and security measures for sensitive data.
          </p>
        </div>
      </div>
    </div>
  );
};
