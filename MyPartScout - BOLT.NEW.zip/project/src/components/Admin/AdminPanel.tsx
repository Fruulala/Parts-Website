import React, { useState } from 'react';
import { AdminLayout } from './AdminLayout';
import { AdminDashboard } from './AdminDashboard';
import { UserManagement } from './UserManagement';
import { OrderManagement } from './OrderManagement';
import { SupplierManagement } from './SupplierManagement';
import { AccountSettings } from './AccountSettings';

interface AdminPanelProps {
  onLogout: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'orders' | 'suppliers' | 'settings'>(
    'dashboard'
  );

  return (
    <AdminLayout activeTab={activeTab} onTabChange={setActiveTab} onLogout={onLogout}>
      {activeTab === 'dashboard' && <AdminDashboard />}
      {activeTab === 'users' && <UserManagement />}
      {activeTab === 'orders' && <OrderManagement />}
      {activeTab === 'suppliers' && <SupplierManagement />}
      {activeTab === 'settings' && <AccountSettings />}
    </AdminLayout>
  );
};
