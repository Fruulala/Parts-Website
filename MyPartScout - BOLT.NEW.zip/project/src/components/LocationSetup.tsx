import React, { useState, useEffect } from 'react';
import { MapPin, Search, Plus, X, Loader2, Check } from 'lucide-react';
import { supabase, Supplier } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface SupplierLocation {
  id?: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  placeId?: string;
}

interface SavedPreference {
  id: string;
  supplier_id: string;
  preferred_location_id: string;
  location?: {
    store_name: string;
    address: string;
    city: string;
    state: string;
    zip_code: string;
  };
}

interface LocationSetupProps {
  onComplete: () => void;
}

export const LocationSetup: React.FC<LocationSetupProps> = ({ onComplete }) => {
  const { user, profile } = useAuth();
  const [step, setStep] = useState<'geolocation' | 'selection'>('geolocation');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [searchZipCode, setSearchZipCode] = useState('');
  const [searchResults, setSearchResults] = useState<SupplierLocation[]>([]);
  const [loading, setLoading] = useState(false);
  const [geolocating, setGeolocating] = useState(false);
  const [savedPreferences, setSavedPreferences] = useState<SavedPreference[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSuppliers();
    loadSavedPreferences();
    detectUserLocation();
  }, []);

  const detectUserLocation = async () => {
    setGeolocating(true);
    try {
      // First try browser geolocation (more accurate on mobile)
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const location = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            setUserLocation(location);

            await supabase
              .from('profiles')
              .update({
                detected_latitude: position.coords.latitude,
                detected_longitude: position.coords.longitude,
              })
              .eq('id', user?.id);

            setGeolocating(false);
            setStep('selection');
          },
          async (error) => {
            console.log('Browser geolocation failed, falling back to IP:', error);
            // Fallback to IP-based geolocation
            await fallbackToIpGeolocation();
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      } else {
        // No browser geolocation support, use IP-based
        await fallbackToIpGeolocation();
      }
    } catch (error) {
      console.error('Geolocation error:', error);
      setStep('selection');
      setGeolocating(false);
    }
  };

  const fallbackToIpGeolocation = async () => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/geolocate-user`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          considerIp: 'true',
          wifiAccessPoints: [],
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const location = { lat: data.location.lat, lng: data.location.lng };
        setUserLocation(location);

        await supabase
          .from('profiles')
          .update({
            detected_latitude: data.location.lat,
            detected_longitude: data.location.lng,
          })
          .eq('id', user?.id);

        setStep('selection');
      } else {
        setStep('selection');
      }
    } catch (error) {
      console.error('IP geolocation error:', error);
      setStep('selection');
    } finally {
      setGeolocating(false);
    }
  };

  const loadSuppliers = async () => {
    const { data } = await supabase
      .from('suppliers')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (data) {
      setSuppliers(data);
    }
  };

  const loadSavedPreferences = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_supplier_preferences')
      .select(`
        id,
        supplier_id,
        preferred_location_id,
        location:supplier_locations(store_name, address, city, state, zip_code)
      `)
      .eq('user_id', user.id);

    if (data) {
      setSavedPreferences(data as any);
    }
  };

  const searchLocations = async (zipCode?: string) => {
    if (!selectedSupplier) return;

    setLoading(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/search-supplier-locations`;

      const searchParams: any = {
        supplierName: selectedSupplier.name,
      };

      if (zipCode) {
        searchParams.zipCode = zipCode;
      } else if (userLocation) {
        searchParams.latitude = userLocation.lat;
        searchParams.longitude = userLocation.lng;
        searchParams.radius = 80467;
      }

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchParams),
      });

      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.locations || []);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSupplierSelect = (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setSearchResults([]);
    setSearchZipCode(profile?.zip_code || '');
  };

  const handleSearch = () => {
    searchLocations(searchZipCode || undefined);
  };

  const addLocation = async (location: SupplierLocation) => {
    if (!selectedSupplier || !user) return;

    setSaving(true);
    try {
      const addressParts = location.address.split(',').map(s => s.trim());
      const cityStateZip = addressParts[addressParts.length - 1];
      const stateParts = cityStateZip.split(' ');

      const { data: supplierLocation, error: locationError } = await supabase
        .from('supplier_locations')
        .insert({
          supplier_id: selectedSupplier.id,
          store_name: location.name,
          address: addressParts.slice(0, -1).join(', '),
          city: addressParts[addressParts.length - 2] || '',
          state: stateParts[0] || '',
          zip_code: stateParts[1] || '',
          latitude: location.latitude,
          longitude: location.longitude,
        })
        .select()
        .single();

      if (locationError) throw locationError;

      const existingPref = savedPreferences.find(p => p.supplier_id === selectedSupplier.id);

      if (existingPref) {
        await supabase
          .from('user_supplier_preferences')
          .update({ preferred_location_id: supplierLocation.id })
          .eq('id', existingPref.id);
      } else {
        await supabase
          .from('user_supplier_preferences')
          .insert({
            user_id: user.id,
            supplier_id: selectedSupplier.id,
            preferred_location_id: supplierLocation.id,
          });
      }

      await loadSavedPreferences();
      setSelectedSupplier(null);
      setSearchResults([]);
      setSearchZipCode('');
    } catch (error) {
      console.error('Error adding location:', error);
      alert('Failed to add location');
    } finally {
      setSaving(false);
    }
  };

  const removePreference = async (preferenceId: string) => {
    await supabase
      .from('user_supplier_preferences')
      .delete()
      .eq('id', preferenceId);

    await loadSavedPreferences();
  };

  const handleComplete = async () => {
    if (user) {
      await supabase
        .from('profiles')
        .update({ has_completed_location_setup: true })
        .eq('id', user.id);
    }
    onComplete();
  };

  if (step === 'geolocation') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl w-full text-center">
          <div className="bg-slate-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
            <MapPin className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Finding Your Location</h2>
          {geolocating ? (
            <>
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900 mb-4"></div>
              <p className="text-slate-600">Detecting your current location...</p>
            </>
          ) : (
            <>
              <div className="mb-6">
                <div className="w-full h-64 bg-slate-200 rounded-lg flex items-center justify-center">
                  {userLocation ? (
                    <div className="text-center">
                      <Check className="w-12 h-12 text-green-600 mx-auto mb-2" />
                      <p className="text-slate-700 font-medium">Location Detected</p>
                      <p className="text-sm text-slate-600">
                        {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
                      </p>
                    </div>
                  ) : (
                    <MapPin className="w-16 h-16 text-slate-400" />
                  )}
                </div>
              </div>
              <button
                onClick={() => setStep('selection')}
                className="bg-slate-900 text-white px-8 py-3 rounded-lg font-semibold hover:bg-slate-800 transition-colors"
              >
                Continue to Location Setup
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Supplier Location Setup</h2>
              <p className="text-slate-600">
                Add your preferred store locations for each supplier
              </p>
            </div>
            {savedPreferences.length > 0 && (
              <button
                onClick={handleComplete}
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
              >
                Complete Setup
              </button>
            )}
          </div>

          {savedPreferences.length > 0 && (
            <div className="mb-8">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Your Saved Locations</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedPreferences.map((pref) => {
                  const supplier = suppliers.find(s => s.id === pref.supplier_id);
                  return (
                    <div key={pref.id} className="border-2 border-slate-200 rounded-lg p-4 flex justify-between items-start">
                      <div>
                        <p className="font-bold text-slate-900">{supplier?.name}</p>
                        <p className="text-sm text-slate-600 mt-1">
                          {pref.location?.store_name}
                        </p>
                        <p className="text-sm text-slate-500">
                          {pref.location?.address}, {pref.location?.city}, {pref.location?.state} {pref.location?.zip_code}
                        </p>
                      </div>
                      <button
                        onClick={() => removePreference(pref.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {!selectedSupplier ? (
            <div>
              <h3 className="text-lg font-bold text-slate-900 mb-4">Select a Supplier</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {suppliers.map((supplier) => {
                  const hasLocation = savedPreferences.some(p => p.supplier_id === supplier.id);
                  return (
                    <button
                      key={supplier.id}
                      onClick={() => handleSupplierSelect(supplier)}
                      className={`p-6 rounded-lg border-2 text-left transition-all hover:shadow-lg ${
                        hasLocation
                          ? 'border-green-500 bg-green-50'
                          : 'border-slate-200 hover:border-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-bold text-slate-900">{supplier.name}</h4>
                        {hasLocation && <Check className="w-5 h-5 text-green-600" />}
                      </div>
                      <p className="text-sm text-slate-600">
                        {hasLocation ? 'Location saved' : 'Click to add location'}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-slate-900">
                  Find {selectedSupplier.name} Locations
                </h3>
                <button
                  onClick={() => {
                    setSelectedSupplier(null);
                    setSearchResults([]);
                  }}
                  className="text-slate-600 hover:text-slate-900"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Search by ZIP Code (or leave blank to use your location)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={searchZipCode}
                    onChange={(e) => setSearchZipCode(e.target.value)}
                    placeholder="Enter ZIP code"
                    className="flex-1 px-4 py-3 border-2 border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  />
                  <button
                    onClick={handleSearch}
                    disabled={loading}
                    className="bg-slate-900 text-white px-6 py-3 rounded-lg font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {loading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Search className="w-5 h-5" />
                    )}
                    Search
                  </button>
                </div>
              </div>

              {searchResults.length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-900 mb-4">
                    Found {searchResults.length} locations
                  </h4>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {searchResults.map((location, index) => (
                      <div
                        key={index}
                        className="border-2 border-slate-200 rounded-lg p-4 flex justify-between items-start hover:border-slate-400 transition-colors"
                      >
                        <div className="flex-1">
                          <p className="font-bold text-slate-900">{location.name}</p>
                          <p className="text-sm text-slate-600 mt-1">{location.address}</p>
                        </div>
                        <button
                          onClick={() => addLocation(location)}
                          disabled={saving}
                          className="bg-slate-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-2 ml-4"
                        >
                          {saving ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <>
                              <Plus className="w-4 h-4" />
                              Add
                            </>
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {savedPreferences.length === 0 && (
            <div className="mt-6 text-center">
              <button
                onClick={handleComplete}
                className="text-slate-600 hover:text-slate-900 text-sm font-medium"
              >
                Skip for now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
