import React, { useState, useEffect } from 'react';
import { ShoppingCart, ArrowLeft, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';

interface SearchResult {
  supplier: string;
  partNumber: string;
  partName: string;
  wholesalePrice: number;
  retailPrice: number;
  availability: string;
}

interface SearchResultsProps {
  vehicle: { year: number; make: string; model: string; engine: string };
  partInfo: { category: string; part: string };
  suppliers: string[];
  onBack: () => void;
  onViewCart: () => void;
}

export const SearchResults: React.FC<SearchResultsProps> = ({
  vehicle,
  partInfo,
  suppliers,
  onBack,
  onViewCart,
}) => {
  const { user } = useAuth();
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [addingToCart, setAddingToCart] = useState<string | null>(null);

  useEffect(() => {
    fetchResults();
  }, []);

  const fetchResults = async () => {
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const mockResults: SearchResult[] = suppliers.flatMap((supplier) => {
      const basePrice = Math.random() * 100 + 50;
      const wholesalePrice = parseFloat(basePrice.toFixed(2));
      const retailPrice = parseFloat((basePrice * 1.4).toFixed(2));

      return [
        {
          supplier,
          partNumber: `${supplier.substring(0, 3).toUpperCase()}-${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
          partName: partInfo.part,
          wholesalePrice,
          retailPrice,
          availability: Math.random() > 0.3 ? 'In Stock' : 'Limited Stock',
        },
      ];
    });

    setResults(mockResults);
    setLoading(false);
  };

  const addToCart = async (result: SearchResult) => {
    if (!user) return;

    setAddingToCart(result.partNumber);

    try {
      const { error } = await supabase.from('cart_items').insert({
        user_id: user.id,
        supplier_name: result.supplier,
        sku: result.partNumber,
        part_number: result.partNumber,
        part_name: result.partName,
        wholesale_price: result.wholesalePrice,
        retail_price: result.retailPrice,
        quantity: 1,
        vehicle_info: vehicle,
      });

      if (error) throw error;

      alert('Added to cart!');
    } catch (error: any) {
      alert('Error adding to cart: ' + error.message);
    } finally {
      setAddingToCart(null);
    }
  };

  const savings = (retail: number, wholesale: number) => {
    return ((retail - wholesale) / retail * 100).toFixed(0);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <PuppyLogo size="sm" />
              <span className="text-sm font-medium text-slate-700">PartScout</span>
            </div>
            <button
              onClick={onViewCart}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
              View Cart
            </button>
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-4 mb-6 space-y-2">
          <div>
            <span className="text-sm font-medium text-slate-600">Vehicle: </span>
            <span className="text-slate-900 font-semibold">
              {vehicle.year} {vehicle.make} {vehicle.model} - {vehicle.engine}
            </span>
          </div>
          <div>
            <span className="text-sm font-medium text-slate-600">Part: </span>
            <span className="text-slate-900 font-semibold">
              {partInfo.category} - {partInfo.part}
            </span>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-slate-900 mb-6">Search Results</h2>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-slate-900 mb-4"></div>
            <p className="text-slate-600">Searching wholesale prices...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {results.map((result) => (
              <div
                key={result.partNumber}
                className="border-2 border-slate-200 rounded-xl p-6 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-xl font-bold text-slate-900">{result.supplier}</h3>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          result.availability === 'In Stock'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {result.availability}
                      </span>
                    </div>

                    <p className="text-lg font-medium text-slate-700 mb-3">{result.partName}</p>

                    <div className="text-sm text-slate-600">
                      <span className="font-medium">Part Number:</span> {result.partNumber}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="mb-4">
                      <div className="text-sm text-slate-600 mb-1">Retail Price</div>
                      <div className="text-lg text-slate-500 line-through">
                        ${result.retailPrice.toFixed(2)}
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="text-sm font-medium text-slate-900 mb-1">Our Price</div>
                      <div className="text-3xl font-bold text-green-600">
                        ${result.wholesalePrice.toFixed(2)}
                      </div>
                      <div className="text-sm text-green-600 font-medium mt-1">
                        Save {savings(result.retailPrice, result.wholesalePrice)}%
                      </div>
                    </div>

                    <button
                      onClick={() => addToCart(result)}
                      disabled={addingToCart === result.partNumber}
                      className="w-full bg-slate-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      {addingToCart === result.partNumber ? 'Adding...' : 'Add to Cart'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
