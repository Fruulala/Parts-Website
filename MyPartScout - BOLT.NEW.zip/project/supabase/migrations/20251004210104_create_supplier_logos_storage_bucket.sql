/*
  # Create Storage Bucket for Supplier Logos

  1. New Storage Bucket
    - `supplier-logos` - Public bucket for storing supplier logo images
  
  2. Security
    - Enable public access for reading logo images
    - Restrict uploads to admin users only
    - Support common image formats (jpg, jpeg, png, gif, webp, svg)
    - Limit file size to 5MB per image
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('supplier-logos', 'supplier-logos', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can view supplier logos"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'supplier-logos');

CREATE POLICY "Admins can upload supplier logos"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'supplier-logos' 
    AND (storage.foldername(name))[1] = 'logos'
    AND EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update supplier logos"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'supplier-logos'
    AND EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete supplier logos"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'supplier-logos'
    AND EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );
