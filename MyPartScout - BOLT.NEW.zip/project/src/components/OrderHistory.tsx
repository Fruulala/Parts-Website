import React, { useState, useEffect } from 'react';
import { FileText, ArrowLeft, Package } from 'lucide-react';
import { supabase, Order, OrderItem } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';

interface OrderHistoryProps {
  onBack: () => void;
}

export const OrderHistory: React.FC<OrderHistoryProps> = ({ onBack }) => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [loading, setLoading] = useState(true);
  const [expandedOrders, setExpandedOrders] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setOrders(data);

      for (const order of data) {
        const { data: items } = await supabase
          .from('order_items')
          .select('*')
          .eq('order_id', order.id);

        if (items) {
          setOrderItems((prev) => ({ ...prev, [order.id]: items }));
        }
      }
    }
    setLoading(false);
  };

  const toggleOrder = (orderId: string) => {
    setExpandedOrders((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(orderId)) {
        newSet.delete(orderId);
      } else {
        newSet.add(orderId);
      }
      return newSet;
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Order History</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-600">Loading orders...</div>
        ) : orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 text-lg">No orders yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => {
              const items = orderItems[order.id] || [];
              const isExpanded = expandedOrders.has(order.id);

              return (
                <div key={order.id} className="border-2 border-slate-200 rounded-xl overflow-hidden">
                  <button
                    onClick={() => toggleOrder(order.id)}
                    className="w-full p-6 text-left hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-bold text-slate-900">
                            {order.order_number}
                          </h3>
                          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium capitalize">
                            {order.status}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600">{formatDate(order.created_at)}</p>
                        <p className="text-sm text-slate-600 mt-1">
                          {items.length} item{items.length !== 1 ? 's' : ''}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-slate-900">
                          ${order.total_amount.toFixed(2)}
                        </div>
                      </div>
                    </div>
                  </button>

                  {isExpanded && items.length > 0 && (
                    <div className="border-t-2 border-slate-200 p-6 bg-slate-50">
                      <h4 className="font-semibold text-slate-900 mb-4">Order Items</h4>
                      <div className="space-y-3">
                        {items.map((item) => (
                          <div
                            key={item.id}
                            className="bg-white p-4 rounded-lg flex items-start justify-between gap-4"
                          >
                            <div className="flex-1">
                              <p className="font-medium text-slate-900">{item.part_name}</p>
                              <p className="text-sm text-slate-600 mt-1">
                                Supplier: {item.supplier_name}
                              </p>
                              <p className="text-sm text-slate-600">
                                Part Number: {item.part_number}
                              </p>
                              {item.vehicle_info && (
                                <p className="text-xs text-slate-500 mt-1">
                                  {item.vehicle_info.year} {item.vehicle_info.make}{' '}
                                  {item.vehicle_info.model}
                                </p>
                              )}
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-slate-900">
                                ${(item.wholesale_price * item.quantity).toFixed(2)}
                              </p>
                              <p className="text-sm text-slate-600">Qty: {item.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 pt-4 border-t border-slate-200">
                        <p className="text-sm text-slate-600 mb-1">Delivery Address</p>
                        <p className="text-slate-900">{order.delivery_address}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
