/*
  # Add City, State, and Zip Code to Profiles

  1. Changes
    - Add `city` column to `profiles` table (text)
    - Add `state` column to `profiles` table (text, 2 characters for state abbreviation)
    - Add `zip_code` column to `profiles` table (text)
    
  2. Notes
    - These fields are optional to avoid breaking existing profiles
    - Existing profiles will have NULL values for these fields until updated
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'city'
  ) THEN
    ALTER TABLE profiles ADD COLUMN city text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'state'
  ) THEN
    ALTER TABLE profiles ADD COLUMN state text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'zip_code'
  ) THEN
    ALTER TABLE profiles ADD COLUMN zip_code text;
  END IF;
END $$;
