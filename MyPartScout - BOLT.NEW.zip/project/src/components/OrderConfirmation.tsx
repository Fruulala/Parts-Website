import React from 'react';
import { CheckCircle, Home, FileText } from 'lucide-react';
import { PuppyLogo } from './PuppyLogo';

interface OrderConfirmationProps {
  orderNumber: string;
  onViewOrders: () => void;
  onNewSearch: () => void;
}

export const OrderConfirmation: React.FC<OrderConfirmationProps> = ({
  orderNumber,
  onViewOrders,
  onNewSearch,
}) => {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
        <div className="flex justify-end mb-4">
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
          <CheckCircle className="w-12 h-12 text-green-600" />
        </div>

        <h2 className="text-3xl font-bold text-slate-900 mb-4">Order Confirmed!</h2>

        <p className="text-lg text-slate-600 mb-2">Thank you for your order</p>

        <div className="bg-slate-50 rounded-lg p-6 mb-8">
          <p className="text-sm text-slate-600 mb-2">Order Number</p>
          <p className="text-2xl font-bold text-slate-900">{orderNumber}</p>
        </div>

        <div className="space-y-3">
          <button
            onClick={onViewOrders}
            className="w-full bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
          >
            <FileText className="w-5 h-5" />
            View Order History
          </button>

          <button
            onClick={onNewSearch}
            className="w-full border-2 border-slate-300 text-slate-700 px-6 py-3 rounded-lg font-medium hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" />
            New Search
          </button>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-200">
          <p className="text-sm text-slate-600">
            A confirmation email has been sent with your order details.
          </p>
        </div>
      </div>
    </div>
  );
};
