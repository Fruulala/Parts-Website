import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AddressRequest {
  streetAddress: string;
  city: string;
  state: string;
  zipCode?: string;
}

interface USPSAddressResponse {
  address: {
    streetAddress: string;
    city: string;
    state: string;
    ZIPCode: string;
    ZIPPlus4?: string;
  };
  matches?: Array<{ code: string; text: string }>;
  corrections?: Array<{ code: string; text: string }>;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const uspsClientId = Deno.env.get("USPS_CLIENT_ID");
    const uspsClientSecret = Deno.env.get("USPS_CLIENT_SECRET");

    if (!uspsClientId || !uspsClientSecret) {
      return new Response(
        JSON.stringify({ error: "USPS credentials not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { streetAddress, city, state, zipCode }: AddressRequest = await req.json();

    if (!streetAddress || !state || (!city && !zipCode)) {
      return new Response(
        JSON.stringify({ error: "Street address, state, and either city or ZIP code are required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const tokenResponse = await fetch("https://apis.usps.com/oauth2/v3/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `grant_type=client_credentials&client_id=${uspsClientId}&client_secret=${uspsClientSecret}`,
    });

    if (!tokenResponse.ok) {
      console.error("Failed to get USPS token:", await tokenResponse.text());
      return new Response(
        JSON.stringify({ error: "Failed to authenticate with USPS" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;

    const params = new URLSearchParams({
      streetAddress,
      state,
    });

    if (city) params.append("city", city);
    if (zipCode) params.append("ZIPCode", zipCode);

    const validationResponse = await fetch(
      `https://apis.usps.com/addresses/v3/address?${params.toString()}`,
      {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Accept": "application/json",
        },
      }
    );

    if (!validationResponse.ok) {
      const errorData = await validationResponse.json();
      console.error("USPS validation error:", errorData);
      
      return new Response(
        JSON.stringify({ 
          error: "Address validation failed",
          details: errorData.error?.message || "Invalid address"
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const validatedAddress: USPSAddressResponse = await validationResponse.json();

    const isExactMatch = validatedAddress.matches?.some(m => m.code === "31");
    const needsMoreInfo = validatedAddress.corrections?.some(c => c.code === "32" || c.code === "22");

    return new Response(
      JSON.stringify({
        validated: true,
        isExactMatch,
        needsMoreInfo,
        address: {
          streetAddress: validatedAddress.address.streetAddress,
          city: validatedAddress.address.city,
          state: validatedAddress.address.state,
          zipCode: validatedAddress.address.ZIPCode,
          zipPlus4: validatedAddress.address.ZIPPlus4,
        },
        matches: validatedAddress.matches,
        corrections: validatedAddress.corrections,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
