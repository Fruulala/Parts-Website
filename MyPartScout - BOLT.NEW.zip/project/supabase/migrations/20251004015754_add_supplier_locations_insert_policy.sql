/*
  # Add Insert Policy for Supplier Locations

  1. Changes
    - Add INSERT policy for authenticated users to create supplier locations
    
  2. Security
    - Allows any authenticated user to add supplier locations
    - This is necessary for users to save locations from Google Places search
*/

CREATE POLICY "Authenticated users can add supplier locations"
  ON supplier_locations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);