import React, { useState, useEffect, useRef } from 'react';
import { MapPin, Search, Plus, X, Loader2, Check, ArrowLeft, CreditCard as Edit2 } from 'lucide-react';
import { supabase, Supplier } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';
import { loadGoogleMaps } from '../lib/googleMaps';

interface SupplierLocation {
  id?: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  placeId?: string;
  phoneNumber?: string;
  distance?: number;
}

interface SavedPreference {
  id: string;
  supplier_id: string;
  preferred_location_id: string;
  supplier?: {
    name: string;
    logo_url?: string;
  };
  location?: {
    id: string;
    store_name: string;
    address: string;
    city: string;
    state: string;
    zip_code: string;
    latitude: number;
    longitude: number;
    phone_number?: string;
  };
}

interface ManageLocationsProps {
  onBack: () => void;
}

export const ManageLocations: React.FC<ManageLocationsProps> = ({ onBack }) => {
  const { user, profile } = useAuth();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [searchZipCode, setSearchZipCode] = useState('');
  const [searchResults, setSearchResults] = useState<SupplierLocation[]>([]);
  const [loading, setLoading] = useState(false);
  const [savedPreferences, setSavedPreferences] = useState<SavedPreference[]>([]);
  const [saving, setSaving] = useState(false);
  const [mapsLoaded, setMapsLoaded] = useState(false);
  const [mapsError, setMapsError] = useState<string | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    loadSuppliers();
    loadSavedPreferences();
    loadMaps();
  }, []);

  useEffect(() => {
    if (mapsLoaded && mapRef.current && !mapInstanceRef.current) {
      initializeMap();
    }
  }, [mapsLoaded]);

  useEffect(() => {
    if (mapInstanceRef.current) {
      updateMapMarkers();
    }
  }, [profile, savedPreferences, searchResults]);

  const loadMaps = async () => {
    try {
      await loadGoogleMaps();
      setMapsLoaded(true);
    } catch (error) {
      console.error('Failed to load Google Maps:', error);
      setMapsError('Google Maps API key is invalid or restricted. The map functionality is temporarily unavailable.');
    }
  };

  const initializeMap = () => {
    if (!mapRef.current) return;

    try {
      const defaultCenter = {
        lat: profile?.detected_latitude || 39.8283,
        lng: profile?.detected_longitude || -98.5795
      };

      mapInstanceRef.current = new google.maps.Map(mapRef.current, {
        center: defaultCenter,
        zoom: profile?.detected_latitude ? 10 : 4,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
      });

      updateMapMarkers();
    } catch (error) {
      console.error('Failed to initialize map:', error);
      setMapsError('Google Maps API key is invalid or restricted. The map functionality is temporarily unavailable.');
    }
  };

  const updateMapMarkers = () => {
    if (!mapInstanceRef.current) return;

    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    const bounds = new google.maps.LatLngBounds();
    let hasMarkers = false;

    if (profile?.detected_latitude && profile?.detected_longitude) {
      const userMarker = new google.maps.Marker({
        position: { lat: profile.detected_latitude, lng: profile.detected_longitude },
        map: mapInstanceRef.current,
        title: 'Your Location',
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: '#3b82f6',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        },
      });
      markersRef.current.push(userMarker);
      bounds.extend(userMarker.getPosition()!);
      hasMarkers = true;
    }

    savedPreferences.forEach((pref) => {
      if (pref.location?.latitude && pref.location?.longitude) {
        const marker = new google.maps.Marker({
          position: { lat: pref.location.latitude, lng: pref.location.longitude },
          map: mapInstanceRef.current!,
          title: `${pref.supplier?.name} - ${pref.location.store_name}`,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#22c55e',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          },
        });

        const infoWindow = new google.maps.InfoWindow({
          content: `
            <div style="padding: 8px;">
              <strong>${pref.supplier?.name}</strong><br/>
              ${pref.location.store_name}<br/>
              <span style="font-size: 12px; color: #666;">${pref.location.address}, ${pref.location.city}</span>
            </div>
          `,
        });

        marker.addListener('click', () => {
          infoWindow.open(mapInstanceRef.current!, marker);
        });

        markersRef.current.push(marker);
        bounds.extend(marker.getPosition()!);
        hasMarkers = true;
      }
    });

    searchResults.forEach((location, index) => {
      const marker = new google.maps.Marker({
        position: { lat: location.latitude, lng: location.longitude },
        map: mapInstanceRef.current!,
        title: location.name,
        label: {
          text: (index + 1).toString(),
          color: '#ffffff',
          fontSize: '12px',
          fontWeight: 'bold',
        },
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: '#f59e0b',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });

      const infoWindow = new google.maps.InfoWindow({
        content: `
          <div style="padding: 8px;">
            <strong>${location.name}</strong><br/>
            <span style="font-size: 12px; color: #666;">${location.address}</span>
          </div>
        `,
      });

      marker.addListener('click', () => {
        infoWindow.open(mapInstanceRef.current!, marker);
      });

      markersRef.current.push(marker);
      bounds.extend(marker.getPosition()!);
      hasMarkers = true;
    });

    if (hasMarkers && markersRef.current.length > 1) {
      mapInstanceRef.current.fitBounds(bounds);
    }
  };

  const loadSuppliers = async () => {
    const { data } = await supabase
      .from('suppliers')
      .select('*')
      .eq('is_active', true)
      .order('name');

    if (data) {
      setSuppliers(data);
    }
  };

  const loadSavedPreferences = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_supplier_preferences')
      .select(`
        id,
        supplier_id,
        preferred_location_id,
        supplier:suppliers(name, logo_url),
        location:supplier_locations(id, store_name, address, city, state, zip_code, latitude, longitude, phone_number)
      `)
      .eq('user_id', user.id);

    if (data) {
      setSavedPreferences(data as any);
    }
  };


  const handleSupplierSelect = async (supplier: Supplier) => {
    setSelectedSupplier(supplier);
    setSearchResults([]);
    setSearchError(null);
    setSearchZipCode(profile?.zip_code || '');

    // Automatically search for locations when supplier is selected
    await searchLocationsForSupplier(supplier);
  };

  const searchLocationsForSupplier = async (supplier: Supplier, zipCode?: string) => {
    setLoading(true);
    setSearchError(null);
    setSearchResults([]);

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/search-supplier-locations`;

      const searchParams: any = {
        supplierName: supplier.name,
      };

      if (zipCode) {
        searchParams.zipCode = zipCode;
      } else if (profile?.detected_latitude && profile?.detected_longitude) {
        searchParams.latitude = profile.detected_latitude;
        searchParams.longitude = profile.detected_longitude;
        searchParams.radius = 40234; // 25 miles
      } else if (profile?.zip_code) {
        searchParams.zipCode = profile.zip_code;
      }

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchParams),
      });

      const data = await response.json();

      if (data.error) {
        setSearchError(data.error);
      } else {
        setSearchResults(data.locations || []);
        if (data.locations && data.locations.length === 0) {
          setSearchError(`No ${supplier.name} locations found within 25 miles. Try a different zip code.`);
        }
      }
    } catch (error) {
      console.error('Search error:', error);
      setSearchError('Failed to search locations. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (selectedSupplier) {
      searchLocationsForSupplier(selectedSupplier, searchZipCode || undefined);
    }
  };

  const addOrUpdateLocation = async (location: SupplierLocation) => {
    if (!selectedSupplier || !user) return;

    setSaving(true);
    try {
      // Parse address from Google Places format
      // Example: "123 Main St, Austin, TX 78701, USA"
      const addressParts = location.address.split(',').map(s => s.trim());

      let street = '';
      let city = '';
      let state = '';
      let zipCode = '';

      if (addressParts.length >= 3) {
        // Street address is first part
        street = addressParts[0];

        // City is second part
        city = addressParts[1];

        // State and ZIP are in third part (e.g., "TX 78701")
        const stateZipPart = addressParts[2];
        const stateZipMatch = stateZipPart.match(/([A-Z]{2})\s*(\d{5}(-\d{4})?)?/);

        if (stateZipMatch) {
          state = stateZipMatch[1];
          zipCode = stateZipMatch[2] || '';
        } else {
          // If no match, try splitting by space
          const parts = stateZipPart.split(' ');
          state = parts[0] || '';
          zipCode = parts[1] || '';
        }
      } else {
        // Fallback for unexpected format
        street = addressParts[0] || location.name;
        city = addressParts[1] || '';
        state = '';
        zipCode = '';
      }

      const { data: supplierLocation, error: locationError } = await supabase
        .from('supplier_locations')
        .insert({
          supplier_id: selectedSupplier.id,
          store_name: location.name,
          address: street,
          city: city,
          state: state,
          zip_code: zipCode,
          latitude: location.latitude,
          longitude: location.longitude,
          phone_number: location.phoneNumber || null,
        })
        .select()
        .single();

      if (locationError) {
        console.error('Location insert error:', locationError);
        throw locationError;
      }

      const existingPref = savedPreferences.find(p => p.supplier_id === selectedSupplier.id);

      if (existingPref) {
        const { error: updateError } = await supabase
          .from('user_supplier_preferences')
          .update({ preferred_location_id: supplierLocation.id })
          .eq('id', existingPref.id);

        if (updateError) {
          console.error('Preference update error:', updateError);
          throw updateError;
        }
      } else {
        const { error: insertError } = await supabase
          .from('user_supplier_preferences')
          .insert({
            user_id: user.id,
            supplier_id: selectedSupplier.id,
            preferred_location_id: supplierLocation.id,
          });

        if (insertError) {
          console.error('Preference insert error:', insertError);
          throw insertError;
        }
      }

      await loadSavedPreferences();
      setSelectedSupplier(null);
      setSearchResults([]);
      setSearchZipCode('');
    } catch (error: any) {
      console.error('Error adding location:', error);
      alert(`Failed to add location: ${error.message || 'Unknown error'}`);
    } finally {
      setSaving(false);
    }
  };

  const removePreference = async (preferenceId: string) => {
    if (!confirm('Are you sure you want to remove this location?')) return;

    await supabase
      .from('user_supplier_preferences')
      .delete()
      .eq('id', preferenceId);

    await loadSavedPreferences();
  };

  const redetectLocation = async () => {
    setLoading(true);
    try {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { data } = await supabase
              .from('profiles')
              .update({
                detected_latitude: position.coords.latitude,
                detected_longitude: position.coords.longitude,
              })
              .eq('id', user?.id)
              .select()
              .single();

            if (data) {
              window.location.reload();
            }
          },
          (error) => {
            alert('Could not detect location: ' + error.message);
            setLoading(false);
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      } else {
        alert('Geolocation is not supported by your browser');
        setLoading(false);
      }
    } catch (error) {
      console.error('Location detection error:', error);
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">Manage Store Locations</h2>
            <p className="text-slate-600">
              Add or update your preferred store locations for each supplier
            </p>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div>
            <div className="bg-slate-50 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Map Legend
                </h3>
                <button
                  onClick={redetectLocation}
                  disabled={loading}
                  className="text-xs bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                  title="Update your current location"
                >
                  {loading ? 'Detecting...' : 'Update Location'}
                </button>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500 border-2 border-white"></div>
                  <span className="text-slate-600">Your Current Location</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500 border-2 border-white"></div>
                  <span className="text-slate-600">Saved Store Locations</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500 border-2 border-white"></div>
                  <span className="text-slate-600">Search Results</span>
                </div>
              </div>
              {profile?.detected_latitude && profile?.detected_longitude && (
                <div className="mt-2 pt-2 border-t border-slate-200">
                  <p className="text-xs text-slate-500">
                    Current: {profile.detected_latitude.toFixed(4)}, {profile.detected_longitude.toFixed(4)}
                  </p>
                </div>
              )}
            </div>

            <div className="relative">
              <div
                ref={mapRef}
                className="w-full h-[500px] rounded-lg border-2 border-slate-300 shadow-md bg-slate-100"
              ></div>
              {!mapsLoaded && !mapsError && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-100 rounded-lg">
                  <div className="text-center">
                    <Loader2 className="w-8 h-8 text-slate-400 animate-spin mx-auto mb-2" />
                    <p className="text-slate-600 text-sm">Loading map...</p>
                  </div>
                </div>
              )}
              {mapsError && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-100 rounded-lg">
                  <div className="text-center p-4">
                    <MapPin className="w-10 h-10 text-red-400 mx-auto mb-2" />
                    <p className="text-red-600 text-sm font-medium">{mapsError}</p>
                    <p className="text-slate-600 text-xs mt-2">Location search will still work below</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            {savedPreferences.length > 0 && !selectedSupplier && (
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">Your Saved Locations</h3>
                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                  {savedPreferences.map((pref) => (
                    <div
                      key={pref.id}
                      className="border-2 border-slate-200 rounded-lg p-4 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <div className="bg-green-100 p-1.5 rounded">
                            <Check className="w-3 h-3 text-green-700" />
                          </div>
                          {pref.supplier?.logo_url && (
                            <img
                              src={pref.supplier.logo_url}
                              alt={`${pref.supplier.name} logo`}
                              className="w-6 h-6 object-contain"
                            />
                          )}
                          <p className="font-bold text-slate-900">{pref.supplier?.name}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              const supplier = suppliers.find(s => s.id === pref.supplier_id);
                              if (supplier) handleSupplierSelect(supplier);
                            }}
                            className="text-slate-600 hover:text-slate-900 transition-colors"
                            title="Change location"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => removePreference(pref.id)}
                            className="text-red-600 hover:text-red-700 transition-colors"
                            title="Remove location"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div className="pl-7">
                        <p className="text-sm font-medium text-slate-700">
                          {pref.location?.store_name}
                        </p>
                        <p className="text-xs text-slate-600">
                          {pref.location?.address}
                        </p>
                        <p className="text-xs text-slate-600">
                          {pref.location?.city}, {pref.location?.state} {pref.location?.zip_code}
                        </p>
                        {pref.location?.phone_number && (
                          <p className="text-xs text-slate-600 mt-1">
                            📞 {pref.location.phone_number}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!selectedSupplier ? (
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-4">
                  {savedPreferences.length > 0 ? 'Add More Locations' : 'Select a Supplier'}
                </h3>
                <div className="grid grid-cols-1 gap-3">
                  {suppliers.map((supplier) => {
                    const hasLocation = savedPreferences.some(p => p.supplier_id === supplier.id);
                    return (
                      <button
                        key={supplier.id}
                        onClick={() => handleSupplierSelect(supplier)}
                        className={`p-4 rounded-lg border-2 text-left transition-all hover:shadow-md ${
                          hasLocation
                            ? 'border-green-500 bg-green-50 hover:border-green-600'
                            : 'border-slate-200 hover:border-slate-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {supplier.logo_url && (
                              <img
                                src={supplier.logo_url}
                                alt={`${supplier.name} logo`}
                                className="w-8 h-8 object-contain"
                              />
                            )}
                            <h4 className="font-bold text-slate-900">{supplier.name}</h4>
                          </div>
                          {hasLocation && (
                            <div className="bg-green-500 p-1 rounded">
                              <Check className="w-3 h-3 text-white" />
                            </div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-slate-200">
                  <div className="flex items-center gap-3">
                    {selectedSupplier.logo_url && (
                      <img
                        src={selectedSupplier.logo_url}
                        alt={`${selectedSupplier.name} logo`}
                        className="w-10 h-10 object-contain"
                      />
                    )}
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {selectedSupplier.name} Locations
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        {loading ? 'Searching...' : `Within 25 miles`}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedSupplier(null);
                      setSearchResults([]);
                      setSearchError(null);
                    }}
                    className="text-slate-600 hover:text-slate-900 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Search Different ZIP Code
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={searchZipCode}
                      onChange={(e) => setSearchZipCode(e.target.value)}
                      placeholder="Enter ZIP code (or leave blank)"
                      className="flex-1 px-3 py-2 border-2 border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent text-sm"
                    />
                    <button
                      onClick={handleSearch}
                      disabled={loading}
                      className="bg-slate-900 text-white px-4 py-2 rounded-lg font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                    >
                      {loading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Leave blank to use your current location
                  </p>
                </div>

                {loading && (
                  <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 text-center">
                    <Loader2 className="w-6 h-6 text-blue-600 animate-spin mx-auto mb-2" />
                    <p className="text-blue-800 text-sm font-medium">Searching for {selectedSupplier.name} locations...</p>
                  </div>
                )}

                {searchError && !loading && (
                  <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4">
                    <p className="text-red-800 text-sm font-medium">{searchError}</p>
                  </div>
                )}

                {searchResults.length > 0 && !loading && (
                  <div>
                    <h4 className="font-bold text-slate-900 mb-3 text-sm">
                      Found {searchResults.length} location{searchResults.length !== 1 ? 's' : ''}
                    </h4>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                      {searchResults.map((location, index) => (
                        <div
                          key={index}
                          className="border-2 border-slate-200 rounded-lg p-3 hover:border-amber-400 hover:shadow-md transition-all"
                        >
                          <div className="flex items-start gap-3">
                            <div className="bg-amber-500 text-white font-bold text-xs w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                              {index + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2 mb-1">
                                <p className="font-bold text-slate-900 text-sm">{location.name}</p>
                                {location.distance !== undefined && (
                                  <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                                    {location.distance} mi
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-600 mt-0.5">{location.address}</p>
                              {location.phoneNumber && (
                                <p className="text-xs text-slate-600 mt-1">
                                  📞 {location.phoneNumber}
                                </p>
                              )}
                            </div>
                            <button
                              onClick={() => addOrUpdateLocation(location)}
                              disabled={saving}
                              className="bg-slate-900 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-1.5 flex-shrink-0"
                            >
                              {saving ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <>
                                  <Plus className="w-3 h-3" />
                                  {savedPreferences.some(p => p.supplier_id === selectedSupplier.id)
                                    ? 'Update'
                                    : 'Add'}
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {!loading && searchResults.length === 0 && searchZipCode && (
                  <div className="text-center py-8 bg-slate-50 rounded-lg border-2 border-slate-200">
                    <MapPin className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                    <p className="text-slate-600 text-sm">No locations found</p>
                    <p className="text-xs text-slate-500 mt-1">Try a different ZIP code</p>
                  </div>
                )}
              </div>
            )}

            {savedPreferences.length === 0 && !selectedSupplier && (
              <div className="text-center p-6 bg-slate-50 rounded-lg border-2 border-slate-200">
                <MapPin className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <p className="text-slate-600 font-medium text-sm">No locations saved yet</p>
                <p className="text-xs text-slate-500 mt-1">
                  Select a supplier above to add your first store location
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
