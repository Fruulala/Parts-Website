import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  first_name: string;
  last_name: string;
  company_name: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  phone_number: string;
  phone_verified: boolean;
  phone_verification_code: string | null;
  phone_verification_expires_at: string | null;
  has_completed_location_setup?: boolean;
  ip_address?: string;
  detected_latitude?: number;
  detected_longitude?: number;
  created_at: string;
  updated_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  url: string;
  username: string;
  password: string;
  is_active: boolean;
  created_at: string;
}

export interface Vehicle {
  id: string;
  year: number;
  make: string;
  model: string;
  engine: string;
  created_at: string;
}

export interface PartCategory {
  id: string;
  name: string;
  slug: string;
  created_at: string;
}

export interface Part {
  id: string;
  category_id: string;
  name: string;
  description: string;
  created_at: string;
}

export interface CartItem {
  id: string;
  user_id: string;
  supplier_name: string;
  sku: string;
  part_number: string;
  part_name: string;
  wholesale_price: number;
  retail_price: number;
  quantity: number;
  vehicle_info: any;
  created_at: string;
}

export interface Order {
  id: string;
  user_id: string;
  order_number: string;
  total_amount: number;
  delivery_address: string;
  payment_method_id: string | null;
  status: string;
  stripe_payment_intent_id: string;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  supplier_name: string;
  sku: string;
  part_number: string;
  part_name: string;
  wholesale_price: number;
  retail_price: number;
  quantity: number;
  vehicle_info: any;
  created_at: string;
}
