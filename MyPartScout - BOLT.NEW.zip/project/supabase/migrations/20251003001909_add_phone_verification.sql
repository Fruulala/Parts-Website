/*
  # Add Phone Verification Support

  1. Changes
    - Add `phone_verified` column to `profiles` table (boolean, default false)
    - Add `phone_verification_code` column to `profiles` table (text, nullable)
    - Add `phone_verification_expires_at` column to `profiles` table (timestamptz, nullable)
    
  2. Notes
    - phone_verified tracks if the phone number has been verified
    - phone_verification_code stores the 6-digit code sent to the user
    - phone_verification_expires_at stores when the code expires (typically 10 minutes)
    - Verification codes should be cleared after successful verification
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'phone_verified'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone_verified boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'phone_verification_code'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone_verification_code text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'phone_verification_expires_at'
  ) THEN
    ALTER TABLE profiles ADD COLUMN phone_verification_expires_at timestamptz;
  END IF;
END $$;
