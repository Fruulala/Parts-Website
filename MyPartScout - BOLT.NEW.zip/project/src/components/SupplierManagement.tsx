import React, { useState, useEffect } from 'react';
import { Settings, Save, ArrowLeft } from 'lucide-react';
import { supabase, Supplier } from '../lib/supabase';
import { PuppyLogo } from './PuppyLogo';

interface SupplierManagementProps {
  onBack: () => void;
}

export const SupplierManagement: React.FC<SupplierManagementProps> = ({ onBack }) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [editedSuppliers, setEditedSuppliers] = useState<Record<string, Partial<Supplier>>>({});

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    const { data, error } = await supabase
      .from('suppliers')
      .select('*')
      .order('name');

    if (!error && data) {
      setSuppliers(data);
    }
    setLoading(false);
  };

  const updateField = (supplierId: string, field: keyof Supplier, value: string | boolean) => {
    setEditedSuppliers((prev) => ({
      ...prev,
      [supplierId]: {
        ...prev[supplierId],
        [field]: value,
      },
    }));
  };

  const saveSupplier = async (supplier: Supplier) => {
    setSaving(supplier.id);

    const updates = editedSuppliers[supplier.id] || {};
    const { error } = await supabase
      .from('suppliers')
      .update(updates)
      .eq('id', supplier.id);

    if (!error) {
      setSuppliers((prev) =>
        prev.map((s) => (s.id === supplier.id ? { ...s, ...updates } : s))
      );
      setEditedSuppliers((prev) => {
        const newEdited = { ...prev };
        delete newEdited[supplier.id];
        return newEdited;
      });
    } else {
      alert('Error saving supplier: ' + error.message);
    }

    setSaving(null);
  };

  const hasChanges = (supplierId: string) => {
    return editedSuppliers[supplierId] && Object.keys(editedSuppliers[supplierId]).length > 0;
  };

  const getFieldValue = (supplier: Supplier, field: keyof Supplier) => {
    return editedSuppliers[supplier.id]?.[field] ?? supplier[field];
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>

        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Supplier Management</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-blue-900">
            Configure your wholesale account credentials for each supplier to enable automatic price fetching.
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-600">Loading suppliers...</div>
        ) : (
          <div className="space-y-6">
            {suppliers.map((supplier) => (
              <div key={supplier.id} className="border-2 border-slate-200 rounded-xl p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-xl font-bold text-slate-900">{supplier.name}</h3>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={getFieldValue(supplier, 'is_active') as boolean}
                      onChange={(e) => updateField(supplier.id, 'is_active', e.target.checked)}
                      className="w-4 h-4 text-slate-900 border-slate-300 rounded focus:ring-slate-900"
                    />
                    <span className="text-sm font-medium text-slate-700">Active</span>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Website URL
                    </label>
                    <input
                      type="url"
                      value={getFieldValue(supplier, 'url') as string}
                      onChange={(e) => updateField(supplier.id, 'url', e.target.value)}
                      placeholder="https://www.example.com"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Username / Account ID
                    </label>
                    <input
                      type="text"
                      value={getFieldValue(supplier, 'username') as string}
                      onChange={(e) => updateField(supplier.id, 'username', e.target.value)}
                      placeholder="Your wholesale account username"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Password / API Key
                    </label>
                    <input
                      type="password"
                      value={getFieldValue(supplier, 'password') as string}
                      onChange={(e) => updateField(supplier.id, 'password', e.target.value)}
                      placeholder="Your wholesale account password"
                      className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>
                </div>

                {hasChanges(supplier.id) && (
                  <button
                    onClick={() => saveSupplier(supplier)}
                    disabled={saving === supplier.id}
                    className="mt-4 bg-slate-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    {saving === supplier.id ? 'Saving...' : 'Save Changes'}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-900">
            <strong>Note:</strong> Credentials are stored securely in the database. For production use, implement additional encryption and security measures for sensitive data.
          </p>
        </div>
      </div>
    </div>
  );
};
