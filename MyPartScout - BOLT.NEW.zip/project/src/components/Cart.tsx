import React, { useState, useEffect } from 'react';
import { ShoppingCart, Trash2, Plus, Minus, ArrowLeft } from 'lucide-react';
import { supabase, CartItem } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';

interface CartProps {
  onBack: () => void;
  onCheckout: () => void;
}

export const Cart: React.FC<CartProps> = ({ onBack, onCheckout }) => {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setCartItems(data);
    }
    setLoading(false);
  };

  const updateQuantity = async (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;

    const { error } = await supabase
      .from('cart_items')
      .update({ quantity: newQuantity })
      .eq('id', itemId);

    if (!error) {
      setCartItems((prev) =>
        prev.map((item) => (item.id === itemId ? { ...item, quantity: newQuantity } : item))
      );
    }
  };

  const removeItem = async (itemId: string) => {
    const { error } = await supabase.from('cart_items').delete().eq('id', itemId);

    if (!error) {
      setCartItems((prev) => prev.filter((item) => item.id !== itemId));
    }
  };

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.wholesale_price * item.quantity,
    0
  );

  const itemsBySupplier = cartItems.reduce((acc, item) => {
    if (!acc[item.supplier_name]) {
      acc[item.supplier_name] = [];
    }
    acc[item.supplier_name].push(item);
    return acc;
  }, {} as Record<string, CartItem[]>);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Continue Shopping
        </button>

        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Shopping Cart</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-600">Loading cart...</div>
        ) : cartItems.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingCart className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 text-lg">Your cart is empty</p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(itemsBySupplier).map(([supplier, items]) => (
              <div key={supplier} className="border-2 border-slate-200 rounded-xl p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4">{supplier}</h3>

                <div className="space-y-4">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg"
                    >
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900 mb-1">{item.part_name}</h4>
                        <div className="text-sm text-slate-600 space-y-1">
                          <div>Part Number: {item.part_number}</div>
                          {item.vehicle_info && (
                            <div className="text-xs">
                              Vehicle: {item.vehicle_info.year} {item.vehicle_info.make}{' '}
                              {item.vehicle_info.model}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-slate-200 rounded transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-slate-200 rounded transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="text-right">
                        <div className="text-lg font-bold text-slate-900">
                          ${(item.wholesale_price * item.quantity).toFixed(2)}
                        </div>
                        <div className="text-sm text-slate-600">
                          ${item.wholesale_price.toFixed(2)} each
                        </div>
                      </div>

                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}

            <div className="border-t-2 border-slate-200 pt-6">
              <div className="flex items-center justify-between mb-6">
                <span className="text-xl font-semibold text-slate-900">Subtotal</span>
                <span className="text-3xl font-bold text-slate-900">
                  ${subtotal.toFixed(2)}
                </span>
              </div>

              <button
                onClick={onCheckout}
                className="w-full bg-slate-900 text-white px-6 py-4 rounded-lg font-medium text-lg hover:bg-slate-800 transition-colors"
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
