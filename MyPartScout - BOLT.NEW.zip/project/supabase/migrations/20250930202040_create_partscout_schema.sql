/*
  # PartScout Application Schema

  1. New Tables
    - `profiles`
      - Extended user profile information
      - `id` (uuid, references auth.users)
      - `first_name` (text)
      - `last_name` (text)
      - `company_name` (text)
      - `address` (text)
      - `phone_number` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `suppliers`
      - Supplier/store configuration
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `url` (text)
      - `username` (text, encrypted)
      - `password` (text, encrypted)
      - `is_active` (boolean)
      - `created_at` (timestamptz)
    
    - `vehicles`
      - Vehicle information cache
      - `id` (uuid, primary key)
      - `year` (integer)
      - `make` (text)
      - `model` (text)
      - `engine` (text)
      - `created_at` (timestamptz)
    
    - `part_categories`
      - Part category information
      - `id` (uuid, primary key)
      - `name` (text)
      - `slug` (text, unique)
      - `created_at` (timestamptz)
    
    - `parts`
      - Parts catalog
      - `id` (uuid, primary key)
      - `category_id` (uuid, references part_categories)
      - `name` (text)
      - `description` (text)
      - `created_at` (timestamptz)
    
    - `part_searches`
      - Search history for parts
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `vehicle_id` (uuid, references vehicles)
      - `part_id` (uuid, references parts)
      - `selected_suppliers` (jsonb)
      - `created_at` (timestamptz)
    
    - `cart_items`
      - Shopping cart items
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `supplier_name` (text)
      - `sku` (text)
      - `part_number` (text)
      - `part_name` (text)
      - `wholesale_price` (decimal)
      - `retail_price` (decimal)
      - `quantity` (integer)
      - `vehicle_info` (jsonb)
      - `created_at` (timestamptz)
    
    - `payment_methods`
      - Stored payment information
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `card_last_four` (text)
      - `card_brand` (text)
      - `stripe_payment_method_id` (text)
      - `is_default` (boolean)
      - `created_at` (timestamptz)
    
    - `orders`
      - Order records
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `order_number` (text, unique)
      - `total_amount` (decimal)
      - `delivery_address` (text)
      - `payment_method_id` (uuid, references payment_methods)
      - `status` (text)
      - `stripe_payment_intent_id` (text)
      - `created_at` (timestamptz)
    
    - `order_items`
      - Items within orders
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `supplier_name` (text)
      - `sku` (text)
      - `part_number` (text)
      - `part_name` (text)
      - `wholesale_price` (decimal)
      - `retail_price` (decimal)
      - `quantity` (integer)
      - `vehicle_info` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for admin operations
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name text NOT NULL,
  last_name text NOT NULL,
  company_name text NOT NULL,
  address text NOT NULL,
  phone_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  url text DEFAULT '',
  username text DEFAULT '',
  password text DEFAULT '',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active suppliers"
  ON suppliers FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Authenticated users can manage suppliers"
  ON suppliers FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert default suppliers
INSERT INTO suppliers (name, is_active) VALUES
  ('AutoZone', true),
  ('O''Reillys', true),
  ('Napa Auto', true),
  ('Advance Auto', true),
  ('XL Parts', true),
  ('WORLDPAC', true)
ON CONFLICT (name) DO NOTHING;

-- Vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  year integer NOT NULL,
  make text NOT NULL,
  model text NOT NULL,
  engine text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(year, make, model, engine)
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view vehicles"
  ON vehicles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can insert vehicles"
  ON vehicles FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Part categories table
CREATE TABLE IF NOT EXISTS part_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE part_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view part categories"
  ON part_categories FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can insert part categories"
  ON part_categories FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Parts table
CREATE TABLE IF NOT EXISTS parts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES part_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE parts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view parts"
  ON parts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can insert parts"
  ON parts FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Part searches table
CREATE TABLE IF NOT EXISTS part_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_id uuid REFERENCES vehicles(id) ON DELETE SET NULL,
  part_id uuid REFERENCES parts(id) ON DELETE SET NULL,
  selected_suppliers jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE part_searches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own searches"
  ON part_searches FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own searches"
  ON part_searches FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Cart items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  supplier_name text NOT NULL,
  sku text NOT NULL,
  part_number text NOT NULL,
  part_name text NOT NULL,
  wholesale_price decimal(10,2) NOT NULL,
  retail_price decimal(10,2) NOT NULL,
  quantity integer DEFAULT 1,
  vehicle_info jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own cart items"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Payment methods table
CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  card_last_four text NOT NULL,
  card_brand text NOT NULL,
  stripe_payment_method_id text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own payment methods"
  ON payment_methods FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payment methods"
  ON payment_methods FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own payment methods"
  ON payment_methods FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own payment methods"
  ON payment_methods FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  order_number text UNIQUE NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  delivery_address text NOT NULL,
  payment_method_id uuid REFERENCES payment_methods(id) ON DELETE SET NULL,
  status text DEFAULT 'pending',
  stripe_payment_intent_id text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  supplier_name text NOT NULL,
  sku text NOT NULL,
  part_number text NOT NULL,
  part_name text NOT NULL,
  wholesale_price decimal(10,2) NOT NULL,
  retail_price decimal(10,2) NOT NULL,
  quantity integer NOT NULL,
  vehicle_info jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert order items for own orders"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );