import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PriceRequest {
  year: number;
  make: string;
  model: string;
  engine: string;
  partCategory: string;
  partName: string;
}

interface PriceResponse {
  supplier: string;
  partNumber: string;
  partName: string;
  wholesalePrice: number;
  retailPrice: number;
  availability: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const requestData: PriceRequest = await req.json();

    const xlpartsUrl = "https://rapid.xlparts.com/login";
    const username = Deno.env.get("XLPARTS_USERNAME") || "";
    const password = Deno.env.get("XLPARTS_PASSWORD") || "";

    const results: PriceResponse[] = [];

    const mockPrice = Math.random() * 100 + 50;
    results.push({
      supplier: "XL Parts",
      partNumber: `XL-${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
      partName: requestData.partName,
      wholesalePrice: parseFloat(mockPrice.toFixed(2)),
      retailPrice: parseFloat((mockPrice * 1.4).toFixed(2)),
      availability: "In Stock",
    });

    return new Response(
      JSON.stringify({ success: true, data: results }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});