/*
  # Sync Role to Auth Metadata

  1. New Functions
    - Function to sync profile role to auth.users app_metadata
  
  2. New Triggers
    - Trigger on profiles INSERT to sync role
    - Trigger on profiles UPDATE to sync role
  
  3. Purpose
    - Keep auth.users app_metadata.role in sync with profiles.role
    - Allows RLS policies to use JWT metadata without recursion
*/

-- Function to sync role to auth metadata
CREATE OR REPLACE FUNCTION sync_role_to_auth_metadata()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE auth.users
  SET raw_app_meta_data = jsonb_set(
    COALESCE(raw_app_meta_data, '{}'::jsonb),
    '{role}',
    to_jsonb(NEW.role)
  )
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger on profile insert
DROP TRIGGER IF EXISTS sync_role_on_insert ON profiles;
CREATE TRIGGER sync_role_on_insert
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION sync_role_to_auth_metadata();

-- Trigger on profile update
DROP TRIGGER IF EXISTS sync_role_on_update ON profiles;
CREATE TRIGGER sync_role_on_update
  AFTER UPDATE OF role ON profiles
  FOR EACH ROW
  WHEN (OLD.role IS DISTINCT FROM NEW.role)
  EXECUTE FUNCTION sync_role_to_auth_metadata();