import React, { useState } from 'react';
import { Package, ChevronRight, ArrowLeft } from 'lucide-react';
import { PuppyLogo } from './PuppyLogo';

interface PartSelectionProps {
  vehicle: { year: number; make: string; model: string; engine: string };
  onNext: (selection: { category: string; part: string }) => void;
  onBack: () => void;
}

const categories = [
  'Brakes', 'Suspension', 'Engine', 'Transmission', 'Electrical', 'Cooling System',
  'Exhaust', 'Fuel System', 'Ignition', 'Filters', 'Belts & Hoses', 'Steering',
  'Lighting', 'Body Parts', 'Interior', 'Climate Control', 'Wipers & Washers',
  'Batteries', 'Oil & Fluids', 'Tools & Equipment'
];

const partsByCategory: Record<string, string[]> = {
  'Brakes': [
    'Brake Pads', 'Brake Rotors', 'Brake Calipers', 'Brake Lines', 'Brake Fluid',
    'Brake Hardware Kit', 'Wheel Cylinders', 'Master Cylinder', 'Brake Drums'
  ],
  'Suspension': [
    'Shocks', 'Struts', 'Control Arms', 'Ball Joints', 'Tie Rod Ends',
    'Sway Bar Links', 'Coil Springs', 'Leaf Springs', 'Bushings'
  ],
  'Engine': [
    'Oil Filter', 'Air Filter', 'Spark Plugs', 'Timing Belt', 'Water Pump',
    'Thermostat', 'Gaskets', 'Engine Mounts', 'Valve Cover Gasket'
  ],
  'Transmission': [
    'Transmission Filter', 'Transmission Fluid', 'Clutch Kit', 'Flywheel',
    'Transmission Mount', 'Shift Cable', 'Axle Shaft'
  ],
  'Electrical': [
    'Battery', 'Alternator', 'Starter', 'Ignition Coil', 'Sensors',
    'Wiring Harness', 'Fuses', 'Relays', 'Switches'
  ],
  'Cooling System': [
    'Radiator', 'Coolant', 'Thermostat', 'Water Pump', 'Radiator Hoses',
    'Cooling Fan', 'Radiator Cap', 'Heater Core'
  ],
  'Exhaust': [
    'Muffler', 'Catalytic Converter', 'Exhaust Manifold', 'Exhaust Pipe',
    'Exhaust Hangers', 'Oxygen Sensor', 'Resonator'
  ],
  'Fuel System': [
    'Fuel Pump', 'Fuel Filter', 'Fuel Injectors', 'Fuel Lines',
    'Fuel Tank', 'Gas Cap', 'Fuel Pressure Regulator'
  ],
  'Ignition': [
    'Spark Plugs', 'Spark Plug Wires', 'Ignition Coil', 'Distributor',
    'Ignition Module', 'Ignition Switch'
  ],
  'Filters': [
    'Oil Filter', 'Air Filter', 'Fuel Filter', 'Cabin Air Filter',
    'Transmission Filter', 'PCV Valve'
  ],
};

export const PartSelection: React.FC<PartSelectionProps> = ({ vehicle, onNext, onBack }) => {
  const [category, setCategory] = useState('');
  const [part, setPart] = useState('');

  const parts = category && partsByCategory[category] ? partsByCategory[category] : [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext({ category, part });
  };

  const isValid = category && part;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to vehicle selection
        </button>

        <div className="bg-slate-50 rounded-xl p-4 mb-6">
          <h3 className="text-sm font-medium text-slate-600 mb-2">Selected Vehicle</h3>
          <p className="text-lg font-semibold text-slate-900">
            {vehicle.year} {vehicle.make} {vehicle.model} - {vehicle.engine}
          </p>
        </div>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <Package className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Select Part</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Part Category
            </label>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPart('');
              }}
              required
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent bg-white"
            >
              <option value="">Select Category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Part
            </label>
            <select
              value={part}
              onChange={(e) => setPart(e.target.value)}
              required
              disabled={!category}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent bg-white disabled:bg-slate-100 disabled:cursor-not-allowed"
            >
              <option value="">Select Part</option>
              {parts.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={!isValid}
            className="w-full bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            Continue
            <ChevronRight className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
