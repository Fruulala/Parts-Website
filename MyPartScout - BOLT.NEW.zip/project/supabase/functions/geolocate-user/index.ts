import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GOOGLE_API_KEY = "AIzaSyByfrdMjv_OSght8bY4sTYCOyS9WL01lmg";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { wifiAccessPoints, considerIp } = await req.json();

    const geolocateResponse = await fetch(
      `https://www.googleapis.com/geolocation/v1/geolocate`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": GOOGLE_API_KEY,
        },
        body: JSON.stringify({
          considerIp: considerIp || "true",
          wifiAccessPoints: wifiAccessPoints || [],
        }),
      }
    );

    if (!geolocateResponse.ok) {
      const error = await geolocateResponse.text();
      throw new Error(`Geolocation API error: ${error}`);
    }

    const data = await geolocateResponse.json();

    return new Response(JSON.stringify(data), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
    });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
