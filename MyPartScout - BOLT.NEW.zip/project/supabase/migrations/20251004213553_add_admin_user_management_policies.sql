/*
  # Add Admin User Management Policies

  1. New Policies
    - Admin can view all profiles
    - Admin can delete any profile (except their own)
  
  2. Security
    - Only users with role='admin' can perform these actions
    - Admins cannot delete their own account to prevent lockout
*/

-- Allow admins to view all profiles
CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Allow admins to delete any profile except their own
CREATE POLICY "Admins can delete user profiles"
  ON profiles FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
    AND id != auth.uid()
  );