import React from 'react';

interface PuppyLogoProps {
  animated?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const PuppyLogo: React.FC<PuppyLogoProps> = ({ animated = false, size = 'md' }) => {
  const sizeMap = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  };

  return (
    <div className={`${sizeMap[size]} relative flex items-center justify-center`}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {animated && (
            <>
              <style>
                {`
                  @keyframes dig {
                    0%, 100% { transform: translateY(0) rotate(0deg); }
                    25% { transform: translateY(-3px) rotate(-5deg); }
                    50% { transform: translateY(2px) rotate(5deg); }
                    75% { transform: translateY(-2px) rotate(-3deg); }
                  }

                  @keyframes wag {
                    0%, 100% { transform: rotate(-20deg); }
                    50% { transform: rotate(20deg); }
                  }

                  @keyframes dirt1 {
                    0% { opacity: 0; transform: translate(0, 0) scale(0); }
                    30% { opacity: 1; }
                    100% { opacity: 0; transform: translate(-15px, -20px) scale(1.5); }
                  }

                  @keyframes dirt2 {
                    0% { opacity: 0; transform: translate(0, 0) scale(0); }
                    30% { opacity: 1; }
                    100% { opacity: 0; transform: translate(15px, -18px) scale(1.2); }
                  }

                  @keyframes dirt3 {
                    0% { opacity: 0; transform: translate(0, 0) scale(0); }
                    30% { opacity: 1; }
                    100% { opacity: 0; transform: translate(-8px, -25px) scale(1); }
                  }

                  .puppy-body {
                    animation: dig 0.5s ease-in-out infinite;
                    transform-origin: center center;
                  }

                  .puppy-tail {
                    animation: wag 0.3s ease-in-out infinite;
                    transform-origin: left center;
                  }

                  .dirt-particle-1 {
                    animation: dirt1 1s ease-out infinite;
                  }

                  .dirt-particle-2 {
                    animation: dirt2 1.2s ease-out infinite;
                    animation-delay: 0.2s;
                  }

                  .dirt-particle-3 {
                    animation: dirt3 0.9s ease-out infinite;
                    animation-delay: 0.4s;
                  }
                `}
              </style>
            </>
          )}
        </defs>

        <g className={animated ? 'puppy-body' : ''}>
          <ellipse cx="50" cy="55" rx="18" ry="20" fill="#D4A574" />

          <circle cx="50" cy="35" r="15" fill="#D4A574" />

          <ellipse cx="45" cy="33" rx="3" ry="4" fill="#8B6F47" />
          <ellipse cx="55" cy="33" rx="3" ry="4" fill="#8B6F47" />

          <circle cx="44" cy="33" r="2" fill="#2D1810" />
          <circle cx="56" cy="33" r="2" fill="#2D1810" />

          <circle cx="43.5" cy="32.5" r="0.8" fill="#FFFFFF" />
          <circle cx="55.5" cy="32.5" r="0.8" fill="#FFFFFF" />

          <ellipse cx="50" cy="38" rx="1.5" ry="2" fill="#2D1810" />
          <path d="M 50 40 Q 47 42 45 41 M 50 40 Q 53 42 55 41" stroke="#2D1810" strokeWidth="1" fill="none" />

          <path d="M 50 40 L 50 44" stroke="#2D1810" strokeWidth="1" />

          <ellipse cx="50" cy="48" rx="6" ry="4" fill="#FFF5E6" />

          <ellipse cx="38" cy="50" rx="4" ry="8" fill="#D4A574" />
          <ellipse cx="62" cy="50" rx="4" ry="8" fill="#D4A574" />

          <ellipse cx="44" cy="70" rx="3" ry="6" fill="#D4A574" />
          <ellipse cx="56" cy="70" rx="3" ry="6" fill="#D4A574" />
          <ellipse cx="44" cy="75" rx="3.5" ry="2" fill="#8B6F47" />
          <ellipse cx="56" cy="75" rx="3.5" ry="2" fill="#8B6F47" />

          <path
            d="M 33 28 Q 30 25 32 22 Q 35 20 37 23 Z"
            fill="#D4A574"
          />
          <path
            d="M 67 28 Q 70 25 68 22 Q 65 20 63 23 Z"
            fill="#D4A574"
          />
        </g>

        <g className={animated ? 'puppy-tail' : ''} style={{ transformOrigin: '68px 48px' }}>
          <path
            d="M 68 48 Q 75 45 78 50 Q 80 55 75 58"
            stroke="#D4A574"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {animated && (
          <>
            <circle className="dirt-particle-1" cx="50" cy="75" r="2" fill="#8B7355" opacity="0" />
            <circle className="dirt-particle-2" cx="50" cy="75" r="1.5" fill="#A0826D" opacity="0" />
            <circle className="dirt-particle-3" cx="50" cy="75" r="1.8" fill="#6B5744" opacity="0" />
            <circle className="dirt-particle-1" cx="52" cy="76" r="1.2" fill="#8B7355" opacity="0" style={{ animationDelay: '0.3s' }} />
            <circle className="dirt-particle-2" cx="48" cy="76" r="1.5" fill="#A0826D" opacity="0" style={{ animationDelay: '0.5s' }} />
          </>
        )}
      </svg>
    </div>
  );
};
