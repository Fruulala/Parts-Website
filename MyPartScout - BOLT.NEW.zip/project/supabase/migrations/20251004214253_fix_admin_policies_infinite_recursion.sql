/*
  # Fix Admin Policies Infinite Recursion

  1. Changes
    - Drop policies causing infinite recursion
    - Recreate policies using app_metadata instead of profiles table lookup
  
  2. Security
    - Store admin role in auth.users app_metadata
    - Use auth.jwt() to check role without querying profiles table
*/

-- Drop the problematic policies
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can delete user profiles" ON profiles;

-- Create new policies using JWT metadata
CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
    OR auth.uid() = id
  );

CREATE POLICY "Admins can delete user profiles"
  ON profiles FOR DELETE
  TO authenticated
  USING (
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
    AND id != auth.uid()
  );