/*
  # Add Supplier Locations and User Preferences

  1. New Tables
    - `supplier_locations`
      - `id` (uuid, primary key)
      - `supplier_id` (uuid, foreign key to suppliers)
      - `store_name` (text)
      - `address` (text)
      - `city` (text)
      - `state` (text, 2 chars)
      - `zip_code` (text)
      - `latitude` (numeric)
      - `longitude` (numeric)
      - `phone` (text)
      - `hours` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `user_supplier_preferences`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `supplier_id` (uuid, foreign key to suppliers)
      - `preferred_location_id` (uuid, foreign key to supplier_locations)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Changes to Existing Tables
    - Add `has_completed_location_setup` (boolean) to profiles table
    - Add `ip_address` (text) to profiles table
    - Add `detected_latitude` (numeric) to profiles table
    - Add `detected_longitude` (numeric) to profiles table

  3. Security
    - Enable RLS on both new tables
    - Add policies for authenticated users to read supplier locations
    - Add policies for users to manage their own preferences
*/

-- Add columns to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'has_completed_location_setup'
  ) THEN
    ALTER TABLE profiles ADD COLUMN has_completed_location_setup boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'ip_address'
  ) THEN
    ALTER TABLE profiles ADD COLUMN ip_address text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'detected_latitude'
  ) THEN
    ALTER TABLE profiles ADD COLUMN detected_latitude numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'detected_longitude'
  ) THEN
    ALTER TABLE profiles ADD COLUMN detected_longitude numeric;
  END IF;
END $$;

-- Create supplier_locations table
CREATE TABLE IF NOT EXISTS supplier_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid REFERENCES suppliers(id) ON DELETE CASCADE NOT NULL,
  store_name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  zip_code text NOT NULL,
  latitude numeric,
  longitude numeric,
  phone text,
  hours text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_supplier_preferences table
CREATE TABLE IF NOT EXISTS user_supplier_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE CASCADE NOT NULL,
  preferred_location_id uuid REFERENCES supplier_locations(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, supplier_id)
);

-- Enable RLS
ALTER TABLE supplier_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_supplier_preferences ENABLE ROW LEVEL SECURITY;

-- RLS Policies for supplier_locations
CREATE POLICY "Anyone can view supplier locations"
  ON supplier_locations
  FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for user_supplier_preferences
CREATE POLICY "Users can view own preferences"
  ON user_supplier_preferences
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_supplier_preferences
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_supplier_preferences
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own preferences"
  ON user_supplier_preferences
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_supplier_locations_supplier_id ON supplier_locations(supplier_id);
CREATE INDEX IF NOT EXISTS idx_supplier_locations_zip_code ON supplier_locations(zip_code);
CREATE INDEX IF NOT EXISTS idx_user_supplier_preferences_user_id ON user_supplier_preferences(user_id);
CREATE INDEX IF NOT EXISTS idx_user_supplier_preferences_supplier_id ON user_supplier_preferences(supplier_id);
