import React from 'react';
import { Search, LogOut, ShoppingCart, MapPin, FileText } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';

interface HomePageProps {
  onStartSearch: () => void;
  onViewOrders: () => void;
  onViewCart: () => void;
  onManageLocations: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onStartSearch,
  onViewOrders,
  onViewCart,
  onManageLocations,
}) => {
  const { profile, signOut } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <PuppyLogo size="md" />
              <h1 className="text-2xl font-bold text-slate-900">PartScout</h1>
            </div>
            <div className="flex items-center gap-6">
              <button
                onClick={onViewCart}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <ShoppingCart className="w-5 h-5" />
                <span className="text-sm font-medium">Cart</span>
              </button>
              <button
                onClick={onViewOrders}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <FileText className="w-5 h-5" />
                <span className="text-sm font-medium">Orders</span>
              </button>
              <div className="h-6 w-px bg-slate-300"></div>
              <span className="text-sm text-slate-600">
                {profile?.first_name} {profile?.last_name}
              </span>
              <button
                onClick={() => signOut()}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">
            Welcome to PartScout
          </h2>
          <p className="text-xl text-slate-600">
            Search wholesale prices across multiple auto parts suppliers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          <button
            onClick={onStartSearch}
            className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all group"
          >
            <div className="bg-slate-900 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Search className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Search Parts</h3>
            <p className="text-slate-600">
              Find and compare prices from multiple suppliers for your vehicle parts
            </p>
          </button>

          <button
            onClick={onManageLocations}
            className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all group"
          >
            <div className="bg-slate-900 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Store Locations</h3>
            <p className="text-slate-600">
              Manage your preferred pickup locations for each supplier
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};
