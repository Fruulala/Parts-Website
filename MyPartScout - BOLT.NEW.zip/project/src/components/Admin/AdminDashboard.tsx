import React, { useState, useEffect } from 'react';
import { DollarSign, ShoppingBag, Users, TrendingUp } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface SalesData {
  month: string;
  total: number;
  orderCount: number;
}

interface SupplierSales {
  supplier_name: string;
  total: number;
  orderCount: number;
}

interface Stats {
  totalSales: number;
  totalOrders: number;
  totalUsers: number;
  avgOrderValue: number;
}

export const AdminDashboard: React.FC = () => {
  const [monthlySales, setMonthlySales] = useState<SalesData[]>([]);
  const [supplierSales, setSupplierSales] = useState<SupplierSales[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalSales: 0,
    totalOrders: 0,
    totalUsers: 0,
    avgOrderValue: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadStats(),
        loadMonthlySales(),
        loadSupplierSales(),
      ]);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    const [ordersResult, usersResult] = await Promise.all([
      supabase.from('orders').select('total_amount'),
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
    ]);

    const orders = ordersResult.data || [];
    const totalSales = orders.reduce((sum, order) => sum + parseFloat(order.total_amount), 0);
    const totalOrders = orders.length;
    const avgOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;

    setStats({
      totalSales,
      totalOrders,
      totalUsers: usersResult.count || 0,
      avgOrderValue,
    });
  };

  const loadMonthlySales = async () => {
    const { data } = await supabase
      .from('orders')
      .select('created_at, total_amount')
      .order('created_at', { ascending: true });

    if (data) {
      const monthlyData = new Map<string, { total: number; count: number }>();

      data.forEach((order) => {
        const date = new Date(order.created_at);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

        if (!monthlyData.has(monthKey)) {
          monthlyData.set(monthKey, { total: 0, count: 0 });
        }

        const current = monthlyData.get(monthKey)!;
        current.total += parseFloat(order.total_amount);
        current.count += 1;
      });

      const salesData: SalesData[] = Array.from(monthlyData.entries()).map(([month, data]) => ({
        month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        total: data.total,
        orderCount: data.count,
      }));

      setMonthlySales(salesData);
    }
  };

  const loadSupplierSales = async () => {
    const { data } = await supabase
      .from('order_items')
      .select('supplier_name, wholesale_price, quantity');

    if (data) {
      const supplierData = new Map<string, { total: number; count: number }>();

      data.forEach((item) => {
        const supplier = item.supplier_name;
        if (!supplierData.has(supplier)) {
          supplierData.set(supplier, { total: 0, count: 0 });
        }

        const current = supplierData.get(supplier)!;
        current.total += parseFloat(item.wholesale_price) * item.quantity;
        current.count += 1;
      });

      const sales: SupplierSales[] = Array.from(supplierData.entries())
        .map(([supplier_name, data]) => ({
          supplier_name,
          total: data.total,
          orderCount: data.count,
        }))
        .sort((a, b) => b.total - a.total);

      setSupplierSales(sales);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-slate-600">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Dashboard Overview</h2>
        <p className="text-slate-600">Monitor your business performance and key metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <p className="text-sm text-slate-600 mb-1">Total Sales</p>
          <p className="text-2xl font-bold text-slate-900">${stats.totalSales.toFixed(2)}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <ShoppingBag className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <p className="text-sm text-slate-600 mb-1">Total Orders</p>
          <p className="text-2xl font-bold text-slate-900">{stats.totalOrders}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <p className="text-sm text-slate-600 mb-1">Total Users</p>
          <p className="text-2xl font-bold text-slate-900">{stats.totalUsers}</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-amber-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-amber-600" />
            </div>
          </div>
          <p className="text-sm text-slate-600 mb-1">Avg Order Value</p>
          <p className="text-2xl font-bold text-slate-900">${stats.avgOrderValue.toFixed(2)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Monthly Sales</h3>
          {monthlySales.length > 0 ? (
            <div className="space-y-3">
              {monthlySales.map((data, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-900">{data.month}</p>
                    <p className="text-xs text-slate-600">{data.orderCount} orders</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-900">${data.total.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-600">No sales data available</p>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Sales by Supplier</h3>
          {supplierSales.length > 0 ? (
            <div className="space-y-3">
              {supplierSales.map((data, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-900">{data.supplier_name}</p>
                    <p className="text-xs text-slate-600">{data.orderCount} items</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-900">${data.total.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-600">No supplier data available</p>
          )}
        </div>
      </div>
    </div>
  );
};
