import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GOOGLE_API_KEY = "AIzaSyByfrdMjv_OSght8bY4sTYCOyS9WL01lmg";

// Haversine formula to calculate distance in miles
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Radius of Earth in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { supplierName, latitude, longitude, radius, zipCode } = await req.json();

    // Use exact supplier name for more accurate results
    let searchQuery = supplierName;
    let location = { lat: latitude, lng: longitude };

    // If zipCode is provided, geocode it first
    if (zipCode && (!latitude || !longitude)) {
      const geocodeResponse = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(zipCode)}&key=${GOOGLE_API_KEY}`
      );

      const geocodeData = await geocodeResponse.json();

      if (geocodeData.status === "REQUEST_DENIED") {
        throw new Error(`Google API Error: ${geocodeData.error_message || 'API key has restrictions'}. Please check your API key settings in Google Cloud Console.`);
      }

      if (!geocodeResponse.ok || geocodeData.status !== "OK") {
        throw new Error(`Geocoding failed: ${geocodeData.status} - ${geocodeData.error_message || 'Unable to geocode zip code'}`);
      }

      if (geocodeData.results && geocodeData.results.length > 0) {
        location = geocodeData.results[0].geometry.location;
      } else {
        throw new Error("Invalid zip code - no results found");
      }
    }

    if (!location.lat || !location.lng) {
      throw new Error("No valid location provided. Please enter a zip code or enable location services.");
    }

    // Search for places using Google Places API (Text Search)
    // 25 mile radius = 40234 meters
    const searchRadius = radius || 40234;
    const placesResponse = await fetch(
      `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(searchQuery)}&location=${location.lat},${location.lng}&radius=${searchRadius}&key=${GOOGLE_API_KEY}`
    );

    const placesData = await placesResponse.json();

    if (placesData.status === "REQUEST_DENIED") {
      throw new Error(`Google API Error: ${placesData.error_message || 'API key has restrictions'}. Please check your API key settings in Google Cloud Console.`);
    }

    if (!placesResponse.ok) {
      throw new Error(`Places API error: ${placesData.status}`);
    }

    if (placesData.status !== "OK" && placesData.status !== "ZERO_RESULTS") {
      throw new Error(`Places API returned status: ${placesData.status}`);
    }

    // Fetch place details for each result to get phone numbers
    const locationsWithDetails = await Promise.all(
      (placesData.results || []).map(async (place: any) => {
        let phoneNumber = null;

        // Fetch place details to get phone number
        try {
          const detailsResponse = await fetch(
            `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=formatted_phone_number&key=${GOOGLE_API_KEY}`
          );
          const detailsData = await detailsResponse.json();
          if (detailsData.status === "OK" && detailsData.result) {
            phoneNumber = detailsData.result.formatted_phone_number || null;
          }
        } catch (error) {
          console.error('Error fetching place details:', error);
        }

        // Calculate distance from user location
        const distance = calculateDistance(
          location.lat,
          location.lng,
          place.geometry.location.lat,
          place.geometry.location.lng
        );

        return {
          name: place.name,
          address: place.formatted_address,
          latitude: place.geometry.location.lat,
          longitude: place.geometry.location.lng,
          placeId: place.place_id,
          rating: place.rating,
          openNow: place.opening_hours?.open_now,
          phoneNumber,
          distance: Math.round(distance * 10) / 10, // Round to 1 decimal place
        };
      })
    );

    // Sort by distance
    const sortedLocations = locationsWithDetails.sort((a, b) => a.distance - b.distance);

    return new Response(JSON.stringify({ locations: sortedLocations, count: sortedLocations.length }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
    });
  } catch (error) {
    console.error('Search error:', error);
    return new Response(
      JSON.stringify({ error: error.message, locations: [] }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
