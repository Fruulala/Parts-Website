import React, { useState } from 'react';
import { Upload, Download, Database, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { PuppyLogo } from './PuppyLogo';

interface VehicleDataImportProps {
  onBack: () => void;
}

export const VehicleDataImport: React.FC<VehicleDataImportProps> = ({ onBack }) => {
  const { user } = useAuth();
  const [importing, setImporting] = useState(false);
  const [jsonData, setJsonData] = useState('');
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleImport = async () => {
    if (!user || !jsonData.trim()) return;

    setImporting(true);
    setResult(null);

    try {
      const vehicles = JSON.parse(jsonData);

      if (!Array.isArray(vehicles)) {
        throw new Error('Data must be an array of vehicle objects');
      }

      const { data: importRecord, error: importError } = await supabase
        .from('vehicle_data_imports')
        .insert({
          source: 'manual_json',
          status: 'processing',
          imported_by: user.id,
        })
        .select()
        .single();

      if (importError) throw importError;

      let successCount = 0;
      let errorCount = 0;

      for (const vehicle of vehicles) {
        const { error } = await supabase.from('vehicles').upsert(
          {
            year: vehicle.year,
            make: vehicle.make,
            model: vehicle.model,
            trim: vehicle.trim || '',
            engine: vehicle.engine || '',
            engine_code: vehicle.engine_code || '',
            engine_displacement: vehicle.engine_displacement || '',
            fuel_type: vehicle.fuel_type || '',
            drive_type: vehicle.drive_type || '',
            vehicle_type: vehicle.vehicle_type || '',
          },
          {
            onConflict: 'year,make,model,trim,engine',
            ignoreDuplicates: false,
          }
        );

        if (error) {
          errorCount++;
        } else {
          successCount++;
        }
      }

      await supabase
        .from('vehicle_data_imports')
        .update({
          status: 'completed',
          records_imported: successCount,
          completed_at: new Date().toISOString(),
        })
        .eq('id', importRecord.id);

      setResult({
        success: true,
        message: `Successfully imported ${successCount} vehicles. ${errorCount > 0 ? `${errorCount} failed.` : ''}`,
      });

      setJsonData('');
    } catch (error: any) {
      setResult({
        success: false,
        message: error.message || 'Failed to import vehicle data',
      });
    } finally {
      setImporting(false);
    }
  };

  const exampleData = [
    {
      year: 2023,
      make: 'Toyota',
      model: 'Camry',
      trim: 'SE',
      engine: '2.5L I4',
      engine_code: 'A25A-FKS',
      engine_displacement: '2.5L',
      fuel_type: 'Gasoline',
      drive_type: 'FWD',
      vehicle_type: 'Car',
    },
    {
      year: 2023,
      make: 'Ford',
      model: 'F-150',
      trim: 'XLT',
      engine: '3.5L V6',
      engine_code: 'ECOBOOST',
      engine_displacement: '3.5L',
      fuel_type: 'Gasoline',
      drive_type: '4WD',
      vehicle_type: 'Truck',
    },
  ];

  const downloadExample = () => {
    const dataStr = JSON.stringify(exampleData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'vehicle-data-example.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-3 rounded-xl">
              <Database className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Vehicle Data Import</h2>
          </div>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-sm text-blue-900 mb-2">
            <strong>Instructions:</strong>
          </p>
          <ol className="text-sm text-blue-900 list-decimal list-inside space-y-1">
            <li>Export vehicle data from XL Parts in JSON format</li>
            <li>Paste the JSON data in the text area below</li>
            <li>Click Import to add the vehicles to your database</li>
          </ol>
        </div>

        <div className="mb-6">
          <button
            onClick={downloadExample}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <Download className="w-4 h-4" />
            Download Example JSON
          </button>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Vehicle Data (JSON)
          </label>
          <textarea
            value={jsonData}
            onChange={(e) => setJsonData(e.target.value)}
            placeholder={JSON.stringify(exampleData, null, 2)}
            rows={15}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent font-mono text-sm"
          />
        </div>

        {result && (
          <div
            className={`mb-6 p-4 rounded-lg ${
              result.success
                ? 'bg-green-50 text-green-900 border border-green-200'
                : 'bg-red-50 text-red-900 border border-red-200'
            }`}
          >
            {result.message}
          </div>
        )}

        <button
          onClick={handleImport}
          disabled={importing || !jsonData.trim()}
          className="w-full bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Upload className="w-5 h-5" />
          {importing ? 'Importing...' : 'Import Vehicle Data'}
        </button>

        <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-900">
            <strong>Note:</strong> To fetch vehicle data automatically from XL Parts, you'll need
            to implement web scraping or API integration. The credentials you provided are stored
            securely in the Supplier Management section and can be used by a developer to build the
            integration.
          </p>
        </div>
      </div>
    </div>
  );
};
