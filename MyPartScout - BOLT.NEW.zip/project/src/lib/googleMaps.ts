let googleMapsLoaded = false;
let googleMapsLoading = false;
const callbacks: (() => void)[] = [];
const errorCallbacks: ((error: Error) => void)[] = [];

export const loadGoogleMaps = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (googleMapsLoaded) {
      resolve();
      return;
    }

    if (googleMapsLoading) {
      callbacks.push(resolve);
      errorCallbacks.push(reject);
      return;
    }

    googleMapsLoading = true;

    // Listen for Google Maps errors
    (window as any).gm_authFailure = () => {
      googleMapsLoading = false;
      const error = new Error('Google Maps API key is invalid or restricted');
      console.error(error);
      reject(error);
      errorCallbacks.forEach(cb => cb(error));
      errorCallbacks.length = 0;
      callbacks.length = 0;
    };

    const script = document.createElement('script');
    const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyByfrdMjv_OSght8bY4sTYCOyS9WL01lmg';

    console.log('Loading Google Maps with API key:', apiKey ? 'Key found' : 'No key');

    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    script.async = true;
    script.defer = true;

    script.onload = () => {
      googleMapsLoaded = true;
      googleMapsLoading = false;
      console.log('Google Maps loaded successfully');
      resolve();
      callbacks.forEach(cb => cb());
      callbacks.length = 0;
      errorCallbacks.length = 0;
    };

    script.onerror = (error) => {
      googleMapsLoading = false;
      console.error('Failed to load Google Maps script:', error);
      const err = new Error('Failed to load Google Maps');
      reject(err);
      errorCallbacks.forEach(cb => cb(err));
      errorCallbacks.length = 0;
      callbacks.length = 0;
    };

    document.head.appendChild(script);
  });
};
