import React, { useState, useEffect } from 'react';
import { CreditCard, MapPin, ArrowLeft, Lock, Store } from 'lucide-react';
import { supabase, CartItem } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { loadStripe } from '@stripe/stripe-js';
import { PuppyLogo } from './PuppyLogo';

interface CheckoutProps {
  onBack: () => void;
  onComplete: (orderNumber: string) => void;
}

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

interface SupplierPreference {
  supplier_name: string;
  location?: {
    store_name: string;
    address: string;
    city: string;
    state: string;
    zip_code: string;
  };
}

export const Checkout: React.FC<CheckoutProps> = ({ onBack, onComplete }) => {
  const { user, profile } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [supplierLocations, setSupplierLocations] = useState<SupplierPreference[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');

  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [confirmAddress, setConfirmAddress] = useState(false);

  useEffect(() => {
    loadCart();
    loadSupplierLocations();
  }, []);

  const loadCart = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', user.id);

    if (!error && data) {
      setCartItems(data);
    }
    setLoading(false);
  };

  const loadSupplierLocations = async () => {
    if (!user) return;

    const { data: cartData } = await supabase
      .from('cart_items')
      .select('supplier_name')
      .eq('user_id', user.id);

    if (!cartData) return;

    const uniqueSuppliers = [...new Set(cartData.map(item => item.supplier_name))];

    const { data: suppliers } = await supabase
      .from('suppliers')
      .select('id, name')
      .in('name', uniqueSuppliers);

    if (!suppliers) return;

    const supplierIds = suppliers.map(s => s.id);

    const { data: preferences } = await supabase
      .from('user_supplier_preferences')
      .select(`
        supplier_id,
        location:supplier_locations(store_name, address, city, state, zip_code)
      `)
      .eq('user_id', user.id)
      .in('supplier_id', supplierIds);

    if (preferences) {
      const locationsMap = preferences.map(pref => {
        const supplier = suppliers.find(s => s.id === pref.supplier_id);
        return {
          supplier_name: supplier?.name || '',
          location: pref.location as any,
        };
      });
      setSupplierLocations(locationsMap);
    }
  };

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.wholesale_price * item.quantity,
    0
  );
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  const formatCardNumber = (value: string) => {
    const cleaned = value.replace(/\s/g, '');
    const formatted = cleaned.match(/.{1,4}/g)?.join(' ') || cleaned;
    return formatted.substring(0, 19);
  };

  const formatExpiry = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length >= 2) {
      return cleaned.substring(0, 2) + '/' + cleaned.substring(2, 4);
    }
    return cleaned;
  };

  const validateCard = () => {
    if (!confirmAddress) {
      setError('Please confirm your delivery address');
      return false;
    }

    const cardNum = cardNumber.replace(/\s/g, '');

    if (cardNum.length < 13 || cardNum.length > 19) {
      setError('Invalid card number');
      return false;
    }

    if (!cardName.trim()) {
      setError('Cardholder name is required');
      return false;
    }

    const expiry = cardExpiry.split('/');
    if (expiry.length !== 2 || expiry[0].length !== 2 || expiry[1].length !== 2) {
      setError('Invalid expiry date');
      return false;
    }

    if (cardCvv.length < 3 || cardCvv.length > 4) {
      setError('Invalid CVV');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    setError('');

    if (!validateCard()) {
      return;
    }

    setProcessing(true);

    try {
      const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user.id,
          order_number: orderNumber,
          total_amount: total,
          delivery_address: profile.address,
          status: 'processing',
          stripe_payment_intent_id: '',
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment-intent`;

      const paymentResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: total,
          currency: 'usd',
          customerEmail: user.email,
          customerName: `${profile.first_name} ${profile.last_name}`,
          orderId: order.id,
        }),
      });

      const paymentData = await paymentResponse.json();

      if (!paymentData.success) {
        throw new Error(paymentData.error || 'Failed to initialize payment');
      }

      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error('Stripe failed to load');
      }

      const expiry = cardExpiry.split('/');
      const cardElement = {
        number: cardNumber.replace(/\s/g, ''),
        exp_month: parseInt(expiry[0]),
        exp_year: parseInt('20' + expiry[1]),
        cvc: cardCvv,
      };

      const { error: confirmError, paymentIntent } = await stripe.confirmCardPayment(
        paymentData.clientSecret,
        {
          payment_method: {
            card: cardElement as any,
            billing_details: {
              name: cardName,
              email: user.email,
            },
          },
        }
      );

      if (confirmError) {
        throw new Error(confirmError.message);
      }

      if (paymentIntent.status === 'succeeded') {
        await supabase
          .from('orders')
          .update({
            status: 'completed',
            stripe_payment_intent_id: paymentIntent.id,
          })
          .eq('id', order.id);

        const orderItems = cartItems.map((item) => ({
          order_id: order.id,
          supplier_name: item.supplier_name,
          sku: item.sku,
          part_number: item.part_number,
          part_name: item.part_name,
          wholesale_price: item.wholesale_price,
          retail_price: item.retail_price,
          quantity: item.quantity,
          vehicle_info: item.vehicle_info,
        }));

        await supabase.from('order_items').insert(orderItems);

        await supabase
          .from('cart_items')
          .delete()
          .eq('user_id', user.id);

        onComplete(orderNumber);
      } else {
        throw new Error('Payment was not successful');
      }
    } catch (error: any) {
      console.error('Payment error:', error);
      setError(error.message || 'Payment failed. Please try again.');
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="text-center py-12 text-slate-600">Loading...</div>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <div className="text-center py-12">
            <p className="text-slate-600 text-lg">Your cart is empty</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Cart
        </button>

        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-slate-900">Checkout</h2>
          <div className="flex items-center gap-2">
            <PuppyLogo size="sm" />
            <span className="text-sm font-medium text-slate-700">PartScout</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {supplierLocations.length > 0 && (
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Store className="w-5 h-5 text-slate-700" />
                <h3 className="text-lg font-semibold text-slate-900">Pickup Locations</h3>
              </div>
              <div className="space-y-3">
                {supplierLocations.map((supplier, index) => (
                  <div key={index} className="bg-slate-50 rounded-lg p-4 border-2 border-slate-200">
                    <p className="font-bold text-slate-900 mb-2">{supplier.supplier_name}</p>
                    {supplier.location ? (
                      <div className="text-sm text-slate-700">
                        <p className="font-medium">{supplier.location.store_name}</p>
                        <p className="text-slate-600 mt-1">
                          {supplier.location.address}
                        </p>
                        <p className="text-slate-600">
                          {supplier.location.city}, {supplier.location.state} {supplier.location.zip_code}
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-500">No preferred location set</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center gap-3 mb-4">
              <MapPin className="w-5 h-5 text-slate-700" />
              <h3 className="text-lg font-semibold text-slate-900">Delivery Address</h3>
            </div>
            <div className="bg-slate-50 rounded-lg p-5 border-2 border-slate-200">
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-600 uppercase tracking-wide font-medium mb-1">Account Holder</p>
                  <p className="text-lg font-semibold text-slate-900">
                    {profile?.first_name} {profile?.last_name}
                  </p>
                </div>

                <div className="border-t border-slate-300 pt-3">
                  <p className="text-xs text-slate-600 uppercase tracking-wide font-medium mb-1">Company Name</p>
                  <p className="text-base font-medium text-slate-900">{profile?.company_name}</p>
                </div>

                <div className="border-t border-slate-300 pt-3">
                  <p className="text-xs text-slate-600 uppercase tracking-wide font-medium mb-1">Delivery Address</p>
                  <p className="text-base text-slate-800">{profile?.address}</p>
                  {(profile?.city || profile?.state || profile?.zip_code) && (
                    <p className="text-base text-slate-800 mt-1">
                      {profile?.city && `${profile.city}, `}
                      {profile?.state && `${profile.state} `}
                      {profile?.zip_code}
                    </p>
                  )}
                </div>

                <div className="border-t border-slate-300 pt-3">
                  <p className="text-xs text-slate-600 uppercase tracking-wide font-medium mb-1">Phone Number</p>
                  <p className="text-base text-slate-800">{profile?.phone_number}</p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t-2 border-slate-300">
                <label className="flex items-start gap-3 cursor-pointer group">
                  <input
                    type="checkbox"
                    required
                    checked={confirmAddress}
                    onChange={(e) => setConfirmAddress(e.target.checked)}
                    className="mt-1 w-5 h-5 rounded border-slate-300 text-slate-900 focus:ring-2 focus:ring-slate-900 cursor-pointer"
                  />
                  <span className="text-sm text-slate-700 group-hover:text-slate-900">
                    <span className="font-medium">I confirm this is the correct delivery address</span>
                    <span className="text-red-600 ml-1">*</span>
                  </span>
                </label>
              </div>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-4">
              <CreditCard className="w-5 h-5 text-slate-700" />
              <h3 className="text-lg font-semibold text-slate-900">Payment Information</h3>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 flex items-start gap-2">
              <Lock className="w-4 h-4 text-blue-700 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-blue-900">
                Your payment is secured with Stripe. Your card information is encrypted and never stored on our servers.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Card Number
                </label>
                <input
                  type="text"
                  required
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Cardholder Name
                </label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Expiry Date
                  </label>
                  <input
                    type="text"
                    required
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(formatExpiry(e.target.value))}
                    placeholder="MM/YY"
                    maxLength={5}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">CVV</label>
                  <input
                    type="text"
                    required
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, '').substring(0, 4))}
                    placeholder="123"
                    maxLength={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-900 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="border-t-2 border-slate-200 pt-6">
            <div className="space-y-2 mb-6">
              <div className="flex justify-between text-slate-700">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>Tax (8%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-slate-900 pt-2 border-t border-slate-200">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={processing}
              className="w-full bg-slate-900 text-white px-6 py-4 rounded-lg font-medium text-lg hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Lock className="w-5 h-5" />
              {processing ? 'Processing Payment...' : `Pay $${total.toFixed(2)}`}
            </button>

            <p className="text-xs text-slate-500 text-center mt-4">
              Powered by Stripe - PCI DSS compliant payment processing
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
